// node combine-code.js
const fs = require('fs');
const path = require('path');

// Configuration
const OUTPUT_FILE = 'all_my_code.txt';
const TARGET_EXTENSIONS = ['.ts', '.tsx']; 
const IGNORED_DIRS = [
  'node_modules', 
  '.git', 
  'playwright-report', 
  'test-results', 
  'blob-report'
];
const IGNORED_FILES = [
  'playwright.config.ts', 
  'package.json', 
  'package-lock.json'
];

function shouldProcess(filePath, stats) {
  const baseName = path.basename(filePath);
  
  if (stats.isDirectory()) {
    return !IGNORED_DIRS.includes(baseName);
  }
  
  if (IGNORED_FILES.includes(baseName)) {
    return false;
  }
  
  return TARGET_EXTENSIONS.includes(path.extname(filePath));
}

function getAllFiles(dirPath, arrayOfFiles = []) {
  const files = fs.readdirSync(dirPath);

  files.forEach((file) => {
    const filePath = path.join(dirPath, file);
    const stats = fs.statSync(filePath);

    if (shouldProcess(filePath, stats)) {
      if (stats.isDirectory()) {
        getAllFiles(filePath, arrayOfFiles);
      } else {
        arrayOfFiles.push(filePath);
      }
    }
  });

  return arrayOfFiles;
}

function combineFiles() {
  const rootDir = process.cwd();
  const allFiles = getAllFiles(rootDir);
  let outputContent = '';

  allFiles.forEach((file) => {
    const relativePath = path.relative(rootDir, file);
    const fileContent = fs.readFileSync(file, 'utf8');
    
    // Add visual separators for clarity
    outputContent += `=========================================\n`;
    outputContent += `FILE: ${relativePath}\n`;
    outputContent += `=========================================\n\n`;
    outputContent += fileContent;
    outputContent += '\n\n';
  });

  fs.writeFileSync(OUTPUT_FILE, outputContent, 'utf8');
  console.log(`Success! Combined ${allFiles.length} files into ${OUTPUT_FILE}`);
}

combineFiles();