import { BigQuery } from '@google-cloud/bigquery';

const bigquery = new BigQuery({
  keyFilename: 'utils/config/gcp-key.json',
  projectId: 'vf-grp-pcs-prd-mgmt-reports-01',
});

export async function runBigQuery(period: string) {
  let whereClause = '';
  const currentDate = new Date();
  switch (period) {
    case 'ThisMonth':
      whereClause = `
        invoice_month = FORMAT_DATE('%Y%m', CURRENT_DATE())
      `;
      break;

    case 'LastMonth':
      whereClause = `
        invoice_month = FORMAT_DATE(
          '%Y%m',
          DATE_SUB(CURRENT_DATE(), INTERVAL 1 MONTH)
        )
      `;
      break;

    case 'LastYear':
      whereClause = `
        invoice_month BETWEEN
          FORMAT_DATE('%Y%m', DATE_TRUNC(DATE_SUB(CURRENT_DATE(), INTERVAL 1 YEAR), YEAR))
          AND
          FORMAT_DATE('%Y%m', LAST_DAY(DATE_SUB(CURRENT_DATE(), INTERVAL 1 YEAR), YEAR))
      `;
      break;

    case 'YearToDate':
      whereClause = `
        invoice_month BETWEEN
          FORMAT_DATE('%Y%m', DATE_TRUNC(CURRENT_DATE(), YEAR))
          AND
          FORMAT_DATE('%Y%m', CURRENT_DATE())
      `;
      break;

    case 'FYTD':
      whereClause = `
        invoice_month BETWEEN
          FORMAT_DATE(
            '%Y%m',
            IF(
              EXTRACT(MONTH FROM CURRENT_DATE()) >= 4,
              DATE(EXTRACT(YEAR FROM CURRENT_DATE()), 4, 1),
              DATE(EXTRACT(YEAR FROM CURRENT_DATE()) - 1, 4, 1)
            )
          )
          AND
          FORMAT_DATE('%Y%m', CURRENT_DATE())
      `;
      break;

    case 'LastFY':
      whereClause = `
        invoice_month BETWEEN
          FORMAT_DATE(
            '%Y%m',
            IF(
              EXTRACT(MONTH FROM CURRENT_DATE()) >= 4,
              DATE(EXTRACT(YEAR FROM CURRENT_DATE()) - 1, 4, 1),
              DATE(EXTRACT(YEAR FROM CURRENT_DATE()) - 2, 4, 1)
            )
          )
          AND
          FORMAT_DATE(
            '%Y%m',
            IF(
              EXTRACT(MONTH FROM CURRENT_DATE()) >= 4,
              DATE(EXTRACT(YEAR FROM CURRENT_DATE()), 3, 31),
              DATE(EXTRACT(YEAR FROM CURRENT_DATE()) - 1, 3, 31)
            )
          )
      `;
      break;

    default:
      throw new Error(`Unsupported period: ${period}`);
  }

  const query = `
  SELECT
      SUM(PCS_Enabler_Cost) AS Value20_PCS_Enabler_Cost,
      SUM(line_item_unblended_cost) AS Value10_line_item_unblended_cost,
      SUM(Annual_Account_Fee) AS Value22_Annual_Account_Fee,
      SUM(Mgmt_Fee) AS Value21_Mgmt_Fee,
      SUM(baseline_q_consumption) AS Value23_baseline_q_consumption
  FROM
      \`vf-grp-pcs-prd-mgmt-reports-01.gdc_pcs_aws_parquet_cur_dataset.vcs_aws_billing_monthly_vams_tbl\`
  WHERE
      bill_billing_entity NOT IN ('null', 'NULL', 'Null')
      AND ${whereClause}
  `;

  console.log('Executing BigQuery:\n', query);
  const [job] = await bigquery.createQueryJob({ query });
  const [rows] = await job.getQueryResults();
  return rows[0];
}