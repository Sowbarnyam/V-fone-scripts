import nodemailer from 'nodemailer';
import path from 'path';
import { logger } from './logger';

export async function sendValidationReportEmail(
    beforeFilterReportPath: string,
    afterFilterReportPath: string
): Promise<void> {
    try {
        const generatedTime = new Date().toLocaleString();
        console.log('SMTP_HOST:', process.env.SMTP_HOST);
        console.log('SMTP_USER:', process.env.SMTP_USER);
        console.log('Sending email...');
        const transporter = nodemailer.createTransport({
            host: 'smtp.office365.com',
            port: 587,
            secure: false,
            requireTLS: true,
            auth: {
                user: process.env.SMTP_USER,
                pass: process.env.SMTP_PASS
            },
            tls: {
                rejectUnauthorized: false
            }
        });

        await transporter.sendMail({
            from: process.env.SMTP_USER,
            to: 'sowbarnya.a@vodafone.com',
            subject: `Table vs Graph Validation Report - ${generatedTime}`,
            html: `
                <p>Hello,</p>
                <p>Please find attached the generated reports.</p>

                <p>
                    Generated Date & Time:
                    <b>${generatedTime}</b>
                </p>

                <p>Attached Reports:</p>
                <ul>
                    <li>initial-report.html</li>
                    <li>filtered-report.html</li>
                </ul>

                <p>Regards,<br>Automation Framework</p>
            `,
            attachments: [
                {
                    filename: 'initial-report.html',
                    path: beforeFilterReportPath
                },
                {
                    filename: 'filtered-report.html',
                    path: afterFilterReportPath
                }
            ]
        });

        logger.info('REPORT EMAIL SENT SUCCESSFULLY');
    } catch (error) {
        logger.error(`FAILED TO SEND EMAIL: ${error}`);
    }
}
``