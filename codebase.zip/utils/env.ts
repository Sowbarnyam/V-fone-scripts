import dotenv from 'dotenv';

dotenv.config();

export const ENV = {
    BASE_URL: process.env.BASE_URL!,
    EMAIL: process.env.EMAIL!,
    PASSWORD: process.env.PASSWORD!,
    DASHBOARD_URL: process.env.DASHBOARD_URL!,
    CLIENT_ID: process.env.CLIENT_ID!,
    CLIENT_SECRET: process.env.CLIENT_SECRET!,
    TOKEN_URL: process.env.TOKEN_URL!,
    API_URL: process.env.API_URL!,

    SMTP_HOST: process.env.SMTP_HOST!,
    SMTP_PORT: process.env.SMTP_PORT!,
    SMTP_USER: process.env.SMTP_USER!,
    SMTP_PASS: process.env.SMTP_PASS!
}