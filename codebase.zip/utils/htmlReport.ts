export function generateHtmlReport(
    reportData: any[],
    timestamp: string,
    reportTitle: string
): string {

    function extractCurrency(value: string): string {
        const match = value?.match(/\$[0-9,.]+[MK]?/i);
        return match ? match[0] : '$0';
    }

    function parseCompactUSD(value: string | number): number {
        if (typeof value === 'number') return value;
        if (!value) return 0;

        const extracted = extractCurrency(value);
        const clean = extracted.replace(/[$,]/g, '').toUpperCase();

        if (clean.includes('M')) {
            return parseFloat(clean.replace('M', '')) * 1000000;
        }

        if (clean.includes('K')) {
            return parseFloat(clean.replace('K', '')) * 1000;
        }

        return parseFloat(clean);
    }

    function detectUnit(value: string, numeric: number): string {
        const upper = (value || '').toUpperCase();

        if (upper.includes('M')) return 'M';
        if (upper.includes('K')) return 'K';

        if (numeric >= 1000000) return 'M';
        if (numeric >= 1000) return 'K';

        return '';
    }

    return `
<!DOCTYPE html>
<html>
<head>
    <title>Table vs Graph Report</title>

    <style>
    body {
        font-family: Arial;
        padding: 20px;
    }

    .top-bar {
        position: fixed;
        top: 20px;
        right: 20px;
    }

    @media print {
        .top-bar {
            display: none !important;
        }
    }

    .dropdown {
        position: relative;
        display: inline-block;
    }

    .dropbtn {
        background-color: #007BFF;
        color: white;
        padding: 10px 15px;
        border-radius: 5px;
        border: none;
        cursor: pointer;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        right: 0;
        background: white;
        border: 1px solid #ccc;
    }

    .dropdown-content a {
        padding: 10px;
        display: block;
        cursor: pointer;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    table {
        border-collapse: collapse;
        width: 100%;
        margin-top: 15px;
    }

    th, td {
        border: 1px solid black;
        padding: 10px;
        text-align: center;
    }

    th {
        background: #4CAF50;
        color: white;
    }

    .Matched {
        background-color: #d4edda;
    }

    .NotMatched {
        background-color: #f8d7da;
    }

    .section-title {
        margin-top: 40px;
        font-size: 20px;
        font-weight: bold;
    }
    </style>
</head>

<body>

<div class="top-bar">
    <div class="dropdown">
        <button class="dropbtn">Download</button>
        <div class="dropdown-content">
            <a onclick="downloadExcel()">Excel</a>
            <a onclick="downloadWord()">Word</a>
            <a onclick="downloadPDF()">PDF</a>
        </div>
    </div>
</div>

<h2>${reportTitle}</h2>
<p><b>Generated At:</b> ${timestamp}</p>

${[
            'initial',
            'LastMonth',
            'ThisMonth',
            'LastYear',
            'YearToDate',
            'FYTD',
            'LastFY'
        ].map(filterType => {

            const filteredData = reportData.filter(
                r => r.filterType === filterType
            );

            if (filteredData.length === 0) return '';

            const accountId = filteredData[0]?.accountId || 'N/A';

            const displayNameMap: Record<string, string> = {
                initial: 'Before Filter',
                LastMonth: 'Last Month',
                ThisMonth: 'This Month',
                LastYear: 'Last Year',
                YearToDate: 'Year To Date',
                FYTD: 'FYTD',
                LastFY: 'Last FY'
            };

            const displayName =
                displayNameMap[filterType] || filterType;

            return `
<h3 class="section-title">
    Filter: ${displayName} (Account: ${accountId})
</h3>

<table>
<tr>
    <th>Cost Validations</th>
    <th>Table Values</th>
    <th>Summary Graph Values</th>
    <th>Difference</th>
    <th>Status</th>
</tr>

${filteredData.map(r => {

                const graphValueNum = parseCompactUSD(r.graphValue);
                const tableValueNum = parseCompactUSD(r.tableSummaryValue);

                const diffValue = Math.abs(
                    graphValueNum - tableValueNum
                );

                const graphUnit = detectUnit(
                    r.graphValue,
                    graphValueNum
                );

                const tableUnit = detectUnit(
                    r.tableSummaryValue,
                    tableValueNum
                );

                let tolerance = 0.01;

                if (tableUnit === 'M') {
                    tolerance = 0.01 * 1000000;
                } else if (tableUnit === 'K') {
                    tolerance = 0.01 * 1000;
                }

                const isMatch = diffValue <= tolerance;

                const statusClass = isMatch
                    ? 'Matched'
                    : 'NotMatched';

                const statusText = isMatch
                    ? 'Matched'
                    : 'Not Matched';

                return `
<tr class="${statusClass}">
    <td>${r.column}</td>
    <td>${extractCurrency(r.tableSummaryValue)}</td>
    <td>${extractCurrency(r.graphValue)}</td>
    <td>${r.difference}</td>
    <td>${statusText}</td>
</tr>`;
            }).join('')}

</table>
`;
        }).join('')}

<script>

function getFullHTML() {
    return "<html><body>" +
           document.body.innerHTML +
           "</body></html>";
}

function triggerDownload(blob, filename) {
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.click();
}

function downloadExcel() {
    const blob = new Blob(
        [getFullHTML()],
        { type: "application/vnd.ms-excel" }
    );
    triggerDownload(blob, "Report.xls");
}

function downloadWord() {
    const blob = new Blob(
        [getFullHTML()],
        { type: "application/msword" }
    );
    triggerDownload(blob, "Report.doc");
}

function downloadPDF() {
    const bar = document.querySelector('.top-bar');
    bar.style.display = 'none';
    window.print();
    setTimeout(() => {
        bar.style.display = 'block';
    }, 500);
}

</script>

</body>
</html>
`;
}