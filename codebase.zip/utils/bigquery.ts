import axios from 'axios';
import qs from 'qs';

export async function bigqueryTableValidation(): Promise<any> {

    const CLIENT_ID = process.env.CLIENT_ID
    const CLIENT_SECRET = process.env.CLIENT_SECRET
    const TOKEN_URL = process.env.TOKEN_URL as string

    try {
        console.log('Authenticating by using Credentials');

        const tokenResponse = await axios.post(
            TOKEN_URL,
            qs.stringify({
                grant_type: 'client_credentials',
                client_id: CLIENT_ID,
                client_secret: CLIENT_SECRET,
            }),
            {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
            }
        );
        const accessToken = tokenResponse.data.access_token;
        console.log('Token Generated Successfully');

        const API_URL = process.env.API_URL as string

        const payload = {
            CloudProvider: "aws",
            DataStore: "VamsMonthlyBilling",
            Filters: [
                {
                    Attribute: "bill_billing_entity",
                    Operator: "NOT IN",
                    Type: "STRING",
                    Value: ["null", "NULL", "Null"]
                },
                {
                    Attribute: "invoice_month",
                    Operator: ">=",
                    Type: "STRING",
                    Value: "202606"
                },
                {
                    Attribute: "invoice_month",
                    Operator: "<=",
                    Type: "STRING",
                    Value: "202606"
                }
            ],
            FiltersJoinWith: "AND",
            GroupBy: [
                "Value1", "Value2", "Value3", "Value4", "Value5",
                "Value6", "Value7", "Value8", "Value9"
            ],
            Join: {
                DataStore: "CloudResourcesMetadata",
                On: {
                    Left: "line_item_usage_account_id",
                    Operator: "=",
                    Right: "account_id"
                },
                Type: "LEFT"
            },
            Limit: 14900,
            Offset: 0,
            OrderBy: ["Value1", "Value8"],
            Projection: [
                { Attribute: "Table_1.invoice_month_name" },
                { Attribute: "Table_1.bill_billing_entity" },
                { Attribute: "Table_1.line_item_usage_account_id" },
                { Attribute: "Table_1.line_item_line_item_type" },
                { Attribute: "Table_2.account_name" },
                { Attribute: "Table_2.local_market" },
                { Attribute: "Table_2.cost_centre" },
                { Attribute: "Table_2.service_level" },
                { Attribute: "Table_2.legacy_service_level" },
                { Attribute: "Table_1.line_item_unblended_cost", Operation: "SUM" },
                { Attribute: "Table_1.UsageAmount_Less_SupportCost", Operation: "SUM" },
                { Attribute: "Table_1.DiscountedUsage", Operation: "SUM" },
                { Attribute: "Table_1.Tax", Operation: "SUM" },
                { Attribute: "Table_1.SupportCost", Operation: "SUM" },
                { Attribute: "Table_1.BundledDiscount", Operation: "SUM" },
                { Attribute: "Table_1.EdpDiscount", Operation: "SUM" },
                { Attribute: "Table_1.Fee", Operation: "SUM" },
                { Attribute: "Table_1.savings_plan_amortized_upfront_commitment_for_billing_period", Operation: "SUM" },
                { Attribute: "Table_1.VPC_Charges", Operation: "SUM" },
                { Attribute: "Table_1.PCS_Enabler_Cost", Operation: "SUM" },
                { Attribute: "Table_1.Mgmt_Fee", Operation: "SUM" },
                { Attribute: "Table_1.Annual_Account_Fee", Operation: "SUM" }
            ],
            SelectGroups: false
        };

        console.log('===== PAYLOAD DATA=====');
        console.log(JSON.stringify(payload, null, 2));

        console.log('Fetching API data');

        const apiResponse = await axios({
            method: 'post',
            url: API_URL,
            headers: {
                Authorization: `Bearer ${accessToken}`,
                'Content-Type': 'application/json',
                'x-vf-api-tenant': 'vodafone'
            },
            data: payload,
        });

        console.log('API Response Received');
        console.log('Formatting and Fecting Bigquery Table');
        const results = apiResponse.data.Results || apiResponse.data.results || [];
        console.log(`Total Results: ${results.length} from the Bigquery Table`);

        const formattedTableData = results.map((row: any) => {
            const v = row.Value || row.value || [];

            return {
                Value1_invoice_month_name: v[0] || 'N/A',
                Value2_bill_billing_entity: v[1] || 'N/A',
                Value3_line_item_usage_account_id: v[2] || 'N/A',
                Value4_line_item_line_item_type: v[3] || 'N/A',
                Value5_account_name: v[4] || 'N/A',
                Value6_local_market: v[5] || 'N/A',
                Value7_cost_centre: v[6] || 'N/A',
                Value8_service_level: v[7] || 'N/A',
                Value9_legacy_service_level: v[8] || 'N/A',

                Value10_line_item_unblended_cost: Number(v[9]) || 0,
                Value11_UsageAmount_Less_SupportCost: Number(v[10]) || 0,
                Value12_DiscountedUsage: Number(v[11]) || 0,
                Value13_Tax: Number(v[12]) || 0,
                Value14_SupportCost: Number(v[13]) || 0,
                Value15_BundledDiscount: Number(v[14]) || 0,
                Value16_EdpDiscount: Number(v[15]) || 0,
                Value17_Fee: Number(v[16]) || 0,
                Value18_savings_plan_amortized_upfront_commitment_for_billing_period: Number(v[17]) || 0,
                Value19_VPC_Charges: Number(v[18]) || 0,
                Value20_PCS_Enabler_Cost: Number(v[19]) || 0,
                Value21_Mgmt_Fee: Number(v[20]) || 0,
                Value22_Annual_Account_Fee: Number(v[21]) || 0,
            };
        });

        console.log('============ SUMMARY TABLE OF BIGQUERY============');
        console.table(
            formattedTableData.slice(0, 10),
            [
                'Value20_PCS_Enabler_Cost',
                'Value10_line_item_unblended_cost',
                'Value22_Annual_Account_Fee',
                'Value21_Mgmt_Fee'
            ]
        );

        const totalMgmtFee = formattedTableData.reduce(
            (sum: any, row: any) => sum + row.Value21_Mgmt_Fee,
            0
        );
        const totalPCS_Enabler_Cost = formattedTableData.reduce(
            (sum: any, row: any) => sum + row.Value20_PCS_Enabler_Cost,
            0
        );

        const totalUnblendedCost = formattedTableData.reduce(
            (sum: any, row: any) => sum + row.Value10_line_item_unblended_cost,
            0
        );

        const totalAnnualAccountFee = formattedTableData.reduce(
            (sum: any, row: any) => sum + row.Value22_Annual_Account_Fee,
            0
        );

        const formatCompactUSD = (value: any) => {
            if (value >= 1_000_000) {
                return `$${(value / 1_000_000).toFixed(2)}M`;
            } else if (value >= 1_000) {
                return `$${(value / 1_000).toFixed(2)}K`;
            } else {
                return `$${value.toFixed(2)}`;
            }
        };

        console.log('TOTAL PCS ENABLER COST(Pcs Enabler Cost - BIGQUERY):', formatCompactUSD(totalPCS_Enabler_Cost));
        console.log('TOTAL UNBLENDED COST(Actual Cost - BIGQUERY):', formatCompactUSD(totalUnblendedCost));
        console.log('TOTAL ANNUAL ACCOUNT FEE(Account Enablement Fee - BIGQUERY):', formatCompactUSD(totalAnnualAccountFee));
        console.log('TOTAL MGMT FEE(Operations and Security - BIGQUERY):', formatCompactUSD(totalMgmtFee));

        const totals = {
            pcs: totalPCS_Enabler_Cost,
            mgmt: totalMgmtFee,
            unblended: totalUnblendedCost,
            annual: totalAnnualAccountFee,
        };

        if (formattedTableData.length > 0) {
            console.log('First Row of the Table:');
            console.log(JSON.stringify(formattedTableData[0], null, 2));
        }

        return totals;
    } catch (error: any) {
        console.error(' ERROR');
        if (error.response) {
            console.error(`Status: ${error.response.status}`);
            console.error(JSON.stringify(error.response.data, null, 2));
        } else {
            console.error(error.message);
        }
    }
}