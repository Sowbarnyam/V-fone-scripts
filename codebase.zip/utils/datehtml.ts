export function generateHtmlReport(
    reportData: any[],
    timestamp: string,
    reportTitle: string
): string {

    function extractCurrency(value: string): string {
        const match = value?.match(/\$[0-9,.]+[MK]?/i);
        return match ? match[0] : '$0';
    }

    return `
<!DOCTYPE html>
<html>
<head>
    <title>Graph vs Table Report</title>

    <style>
    body { font-family: Arial; padding: 20px; }

    .top-bar {
        position: fixed;
        top: 20px;
        right: 20px;
    }

    @media print {
        .top-bar { display: none !important; }
    }

    .dropdown { position: relative; display: inline-block; }

    .dropbtn {
        background-color: #007BFF;
        color: white;
        padding: 10px 15px;
        border-radius: 5px;
        border: none;
        cursor: pointer;
    }

    .dropdown-content {
        display: none;
        position: absolute;
        right: 0;
        background: white;
        border: 1px solid #ccc;
    }

    .dropdown-content a {
        padding: 10px;
        display: block;
        cursor: pointer;
    }

    .dropdown:hover .dropdown-content {
        display: block;
    }

    table {
        border-collapse: collapse;
        width: 100%;
        margin-top: 15px;
    }

    th, td {
        border: 1px solid black;
        padding: 10px;
        text-align: center;
    }

    th {
        background: #4CAF50;
        color: white;
    }

    .Matched { background-color: #d4edda; }
    .NotMatched { background-color: #f8d7da; }

    .section-title {
        margin-top: 40px;
        font-size: 20px;
        font-weight: bold;
    }
    </style>
</head>

<body>

<div class="top-bar">
    <div class="dropdown">
        <button class="dropbtn">Download</button>
        <div class="dropdown-content">
            <a onclick="downloadExcel()">Excel</a>
            <a onclick="downloadWord()">Word</a>
            <a onclick="downloadPDF()">PDF</a>
        </div>
    </div>
</div>

<h2>${reportTitle}</h2>
<p><b>Generated At:</b> ${timestamp}</p>

${['initial','last7days','rolling30days','lastCalendarMonth'].map(filterType => {

    const filteredData = reportData.filter(r => r.filterType === filterType);
    if (filteredData.length === 0) return '';

    const accountId = filteredData[0]?.accountId || 'N/A';

    const displayName =
        filterType === 'initial'
            ? 'Before Filter'
            : filterType;

    return `
<h3 class="section-title">
    Filter: ${displayName} (Account: ${accountId})
</h3>

<table>
<tr>
    <th>Cost Validations</th>
    <th>Summary Graph Values</th>
    <th>Table Values</th>
    <th>Difference</th>
    <th>Status</th>
</tr>

${filteredData.map(r => `
<tr class="${r.status === 'PASS' ? 'Matched' : 'NotMatched'}">
    <td>${r.column}</td>
    <td>${extractCurrency(r.graphValue)}</td>
    <td>${extractCurrency(r.tableSummaryValue)}</td>
    <td>${r.difference}</td>
    <td>${r.status === 'PASS' ? 'Matched' : 'Not Matched'}</td>
</tr>`).join('')}

</table>
`;
}).join('')}

<script>
function getFullHTML() {
    return "<html><body>" + document.body.innerHTML + "</body></html>";
}

function triggerDownload(blob, filename) {
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    link.click();
}

function downloadExcel() {
    const blob = new Blob([getFullHTML()], { type: "application/vnd.ms-excel" });
    triggerDownload(blob, "Report.xls");
}

function downloadWord() {
    const blob = new Blob([getFullHTML()], { type: "application/msword" });
    triggerDownload(blob, "Report.doc");
}

function downloadPDF() {
    const bar = document.querySelector('.top-bar');
    bar.style.display = 'none';
    window.print();
    setTimeout(() => bar.style.display = 'block', 500);
}
</script>

</body>
</html>
`;
}