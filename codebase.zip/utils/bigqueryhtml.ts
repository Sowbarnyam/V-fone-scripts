export function buildHtmlReport(reportRows: any[]) {

    const timestamp = new Date().toLocaleString();

    const periodLabels: Record<string, string> = {
        LastMonth: 'Last Month',
        ThisMonth: 'This Month',
        LastYear: 'Last Year',
        YearToDate: 'Year To Date',
        FYTD: 'FYTD',
        LastFY: 'Last FY'
    };

    const periods = [
        'LastMonth',
        'ThisMonth',
        'LastYear',
        'YearToDate',
        'FYTD',
        'LastFY'
    ];

    let totalPass = 0;
    let totalFail = 0;

    const allTables = periods.map(period => {

        const rows = reportRows
            .filter(row => row.period === period)
            .map(row => {

                const difference =
                    Math.abs(row.ui - row.bigquery);

                const uiFormatted = row.uiValue;
                const bqFormatted = row.bigqueryValue;

                let isMatch =
                    uiFormatted === bqFormatted;

                if (!isMatch) {

                    if (
                        row.difference.includes('M') &&
                        parseFloat(
                            row.difference
                                .replace('$', '')
                                .replace('M', '')
                        ) <= 0.01
                    ) {
                        isMatch = true;
                    }

                    else if (
                        row.difference.includes('K') &&
                        parseFloat(
                            row.difference
                                .replace('$', '')
                                .replace('K', '')
                        ) <= 0.01
                    ) {
                        isMatch = true;
                    }

                    else if (
                        !row.difference.includes('M') &&
                        !row.difference.includes('K') &&
                        difference <= 0.01
                    ) {
                        isMatch = true;
                    }
                }

                if (isMatch) {
                    totalPass++;
                } else {
                    totalFail++;
                }

                return `
<tr class="${isMatch ? 'matched' : 'mismatch'}">

    <td>${row.column}</td>

    <td>${row.bigqueryValue}</td>

    <td>${row.uiValue}</td>

    <td>
        ${row.difference}
    </td>

    <td>
        ${isMatch ? 'Matched' : 'Not Matched'}
    </td>

</tr>

                `;
            })
            .join('');

        return `
        <div class="filter-section">

            <h2>
                Filter: ${periodLabels[period]}
            </h2>

            <table>

                <tr>
                    <th>Cost Validations</th>
                    <th>BigQuery Values</th>
                    <th>UI Values</th>
                    <th>Difference</th>
                    <th>Status</th>
                </tr>

                ${rows}

            </table>

        </div>
        `;
    }).join('');

    return `
<!DOCTYPE html>

<html>

<head>

<title>
BigQuery vs UI Validation Report - All Filters
</title>

<style>

body{
    font-family: Arial, sans-serif;
    background:#efefef;
    padding:20px;
}

.header{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
}

h1{
    margin:0;
    font-size:22px;
}

.timestamp{
    margin-top:20px;
    font-size:16px;
}

.summary{
    background:white;
    padding:15px;
    margin-top:20px;
    border-radius:6px;
    font-size:16px;
}

.filter-section{
    margin-top:50px;
}

table{
    width:100%;
    border-collapse:collapse;
    margin-top:20px;
    background:white;
}

th{
    background:#4CAF50;
    color:white;
    padding:14px;
    border:1px solid black;
    font-size:16px;
}

td{
    border:1px solid black;
    padding:12px;
    text-align:center;
    font-size:15px;
}

.matched{
    background:#cfe0d1;
}

.mismatch{
    background:#e8caca;
}

.download-container{
    position:relative;
}

.download-btn{
    padding:12px 22px;
    background:#0078D4;
    color:white;
    border:none;
    border-radius:6px;
    cursor:pointer;
}

.dropdown{
    display:none;
    position:absolute;
    right:0;
    background:white;
    min-width:150px;
    box-shadow:0px 4px 12px rgba(0,0,0,0.15);
    border-radius:6px;
}

.dropdown div{
    padding:10px;
    cursor:pointer;
}

.dropdown div:hover{
    background:#f0f0f0;
}

</style>

<script>

function toggleDropdown() {

    const dropdown =
        document.getElementById("dropdown");

    dropdown.style.display =
        dropdown.style.display === "block"
            ? "none"
            : "block";
}

function downloadFile(type) {

    const content =
        document.documentElement.outerHTML;

    let blob;
    let filename;

    if(type === 'excel') {

        blob = new Blob(
            [content],
            {
               type: 'application/vnd.ms-excel'
            }
        );

        filename = 'BigQuery_Report.xls';
    }

    if(type === 'word') {

        blob = new Blob(
            [
                '<html><body>' +
                content +
                '</body></html>'
            ],
            {
                type:'application/msword'
            }
        );

        filename = 'BigQuery_Report.doc';
    }

    const a =
        document.createElement('a');

    a.href =
        URL.createObjectURL(blob);

    a.download =
        filename;

    a.click();

    document.getElementById(
        'dropdown'
    ).style.display = 'none';
}

window.onclick = function(event){

    if(!event.target.matches('.download-btn')) {

        const dropdown =
            document.getElementById(
                'dropdown'
            );

        if(dropdown) {
            dropdown.style.display='none';
        }
    }
}

</script>

</head>

<body>

<div class="header">

    <div>

        <h1>
            BigQuery vs UI Validation Report - All Filters
        </h1>

        <div class="timestamp">
            <strong>Generated At:</strong>
            ${timestamp}
        </div>

    </div>

    <div class="download-container">

        <button
            class="download-btn"
            onclick="toggleDropdown()">

            Download

        </button>

        <div
            class="dropdown"
            id="dropdown">

            <div onclick="downloadFile('excel')">
                Excel
            </div>

            <div onclick="downloadFile('word')">
                Word
            </div>

        </div>

    </div>

</div>

<div class="summary">

    <strong>Total Validations:</strong>
    ${reportRows.length}

    &nbsp;&nbsp;&nbsp;

     <strong>Matched:</strong>
    ${totalPass}

    &nbsp;&nbsp;&nbsp;

     <strong>Not Matched:</strong>
    ${totalFail}

</div>

${allTables}

</body>

</html>`;
}