import { test, Page, expect } from '@playwright/test';
import { ENV } from '../utils/env';
import { loginLocators } from '../locators/loginLocators';
import { logger } from '../utils/logger';
import { dashboardLocators } from '../locators/dashboardLocators';

export class LoginPage {
    constructor(private page: Page) { }

    async navigateToLoginPage() {
        logger.info(`Navigating core gateway to base endpoint URL: ${ENV.BASE_URL}`);
        try {
            await this.page.goto(ENV.BASE_URL);
        } catch (error: any) {
            logger.error('Failed to load login landing portal', error);
            throw new Error(`Portal Initialization Failure: ${error.message}`);
        }
    }

    async login(email: string) {
        logger.info(`Filling authentication criteria details for target account: ${email}`);
        try {
            const emailInput = this.page.locator(loginLocators.emailInput);
            await emailInput.clear();
            await emailInput.fill(email);
            await this.page.locator(loginLocators.continueBtn).click();
        } catch (error) {
            logger.error('Initial stage login credential parsing failed', error);
            throw error;
        }
    }

    async authenticationLogin() {
        logger.info('Evaluating SSO/MFA Authentication workflows window...');
        try {
            await this.page.waitForLoadState('load');
            let isLoggedOut = false;
            const emailInput = this.page.locator(loginLocators.authEmailInput);
            const isEmailFormPresent = await emailInput.isVisible({ timeout: 15000 }).catch(() => false);
            if (isEmailFormPresent) {
                isLoggedOut = true;
                logger.info('Email challenge detected. Preparing input field...');
                await emailInput.waitFor({ state: 'visible', timeout: 15000 });
                await emailInput.click();
                await emailInput.clear();
                logger.info('Filling email address sequentially...');
                await emailInput.pressSequentially(ENV.EMAIL, { delay: 50 });
                const nextBtn = this.page.locator(loginLocators.authNextBtn);
                await nextBtn.waitFor({ state: 'visible', timeout: 10000 });
                await nextBtn.click();
                const passwordInput = this.page.locator(loginLocators.authPassword);
                await passwordInput.waitFor({ state: 'visible', timeout: 20000 });
                await passwordInput.click();
                await passwordInput.clear();
                logger.info('Filling password field sequentially...');
                await passwordInput.pressSequentially(ENV.PASSWORD, { delay: 50 });
                await nextBtn.waitFor({ state: 'visible', timeout: 10000 });
                await nextBtn.click();
            } else {
                const passwordInput = this.page.locator(loginLocators.authPassword);
                const isPasswordFormPresent = await passwordInput.isVisible({ timeout: 10000 }).catch(() => false);
                if (isPasswordFormPresent) {
                    isLoggedOut = true;
                    logger.info('Password challenge detected. Proceeding with UI login flow...');
                    await passwordInput.waitFor({ state: 'visible', timeout: 10000 });
                    await passwordInput.click();
                    await passwordInput.clear();
                    await passwordInput.pressSequentially(ENV.PASSWORD, { delay: 50 });
                    await this.page.click(loginLocators.authNextBtn);
                } else {
                    logger.info('Password challenge skipped. Device or session already recognized.');
                }
            }
            if (isLoggedOut) {
                logger.info('MFA required. Boosting overall test timeout to 120 seconds...');
                test.setTimeout(120000);
                logger.info('Waiting for manual mobile MFA authentication code input confirmation...');
                const yesBtn = this.page.locator(loginLocators.authYesBtn);
                await yesBtn.waitFor({ state: 'visible', timeout: 60000 });
                await yesBtn.click();
                logger.info('YES button clicked. Waiting for dashboard URL redirect...');
                await this.page.waitForURL(loginLocators.dashboardUrl, { timeout: 60000 });
                const dashboardTab = this.page.locator(dashboardLocators.vCloudSmartTab);
                await dashboardTab.waitFor({ state: 'visible', timeout: 30000 });
            } else {
                logger.info('Session active. Routing directly to dashboard...');
                await this.page.waitForURL(loginLocators.dashboardUrl, { timeout: 30000 });
                await this.page.locator(dashboardLocators.vCloudSmartTab).waitFor({ state: 'visible', timeout: 20000 });
            }
            logger.info('Successfully verified dashboard view destination.');
        } catch (error: any) {
            logger.error('Critical Authorization Handshake Error encountered.', error);
            throw new Error(`Authentication Handshake Aborted: ${error.message}`);
        }
    }

}


