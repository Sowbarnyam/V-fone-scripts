// ====================================================================
// PURPOSE: Global Base POM handling data grid actions and assertions.
// USAGE:   Inherited by sub-pages to execute rapid, auto-waiting actions.
// ====================================================================

import { test, Page, expect } from '@playwright/test';
import { commonLocators, dashboardLocators, paginationLocators } from '../locators/dashboardLocators';
import { logger } from '../utils/logger';

export class BaseTablePage {
    constructor(protected page: Page) { }


    async handleTutorialPopup(): Promise<void> {
        const popupSelector = 'button:has-text("Cancel"), span:has-text("Cancel"), a:has-text("Cancel")';
        const maxPopups = 5;
        for (let i = 1; i <= maxPopups; i++) {
            try {
                logger.info(`Checking for tutorial popup (Attempt #${i})`);
                const popup = this.page.locator(popupSelector).first();
                await popup.waitFor({ state: 'visible', timeout: 3000 });
                logger.info('Tutorial popup detected. Clicking Cancel...');
                await popup.click({ force: true });
                await this.page.waitForTimeout(1500);
                const stillVisible = await popup.isVisible().catch(() => false);
                if (!stillVisible) {
                    logger.info('Popup closed successfully.');
                }
            } catch {
                logger.info('No tutorial popup found.');
                break;
            }
        }
    }
    /**
     * Direct navigation to target cloud context without static wait traps
     */
    async navigateToAWS(): Promise<void> {
        logger.info('Navigating to AWS Cloud Smart Dashboard');
        try {
            test.setTimeout(900 * 1000);
            await this.page.waitForSelector(dashboardLocators.vCloudSmartTab, { timeout: 15000 });
            await this.page.click(dashboardLocators.vCloudSmartTab);
            await this.handleTutorialPopup();
            await this.page.waitForSelector(dashboardLocators.awsCard, { timeout: 15000 });
            await this.page.click(dashboardLocators.awsCard);
            await this.handleTutorialPopup();
            await this.page.waitForLoadState('networkidle').catch(() => { });
            await this.page.waitForLoadState('domcontentloaded');
            logger.info('Successfully anchored on target AWS cloud view panel.');
        } catch (error: any) {
            logger.error('Failed to navigate to AWS dashboard section', error);
            throw new Error(`AWS Navigation Failure: ${error.message}`);
        }
    }

    async navigateToGCP(): Promise<void> {
        logger.info('Navigating to GCP Cloud Smart Dashboard');
        try {
            test.setTimeout(900 * 1000);
            await this.page.waitForSelector(dashboardLocators.vCloudSmartTab, { timeout: 15000 });
            await this.page.click(dashboardLocators.vCloudSmartTab);
            await this.handleTutorialPopup();
            await this.page.waitForSelector(dashboardLocators.gcpCard, { timeout: 15000 });
            await this.page.click(dashboardLocators.gcpCard);
            await this.handleTutorialPopup();
            await this.page.waitForLoadState('networkidle').catch(() => { });
            await this.page.waitForLoadState('domcontentloaded');
            logger.info('Successfully anchored on target GCP cloud view panel.');
        } catch (error: any) {
            logger.error('Failed to navigate to GCP dashboard section', error);
            throw new Error(`AWS Navigation Failure: ${error.message}`);
        }
    }

    async navigateToAzure(): Promise<void> {
        logger.info('Navigating to GCP Cloud Smart Dashboard');
        try {
            test.setTimeout(900 * 1000);
            await this.page.waitForSelector(dashboardLocators.vCloudSmartTab, { timeout: 15000 });
            await this.page.click(dashboardLocators.vCloudSmartTab);
            await this.handleTutorialPopup();
            await this.page.waitForSelector(dashboardLocators.azureCard, { timeout: 15000 });
            await this.page.click(dashboardLocators.azureCard);
            await this.handleTutorialPopup();
            await this.page.waitForLoadState('networkidle').catch(() => { });
            await this.page.waitForLoadState('domcontentloaded');
            logger.info('Successfully anchored on target GCP cloud view panel.');
        } catch (error: any) {
            logger.error('Failed to navigate to GCP dashboard section', error);
            throw new Error(`AWS Navigation Failure: ${error.message}`);
        }
    }

    async navigateToOracleCloud(): Promise<void> {
        logger.info('Navigating to GCP Cloud Smart Dashboard');
        try {
            test.setTimeout(900 * 1000);
            await this.page.waitForSelector(dashboardLocators.vCloudSmartTab, { timeout: 15000 });
            await this.page.click(dashboardLocators.vCloudSmartTab);
            await this.handleTutorialPopup();
            await this.page.waitForSelector(dashboardLocators.oracleCard, { timeout: 15000 });
            await this.page.click(dashboardLocators.oracleCard);
            await this.handleTutorialPopup();
            await this.page.waitForLoadState('networkidle').catch(() => { });
            await this.page.waitForLoadState('domcontentloaded');
            logger.info('Successfully anchored on target GCP cloud view panel.');
        } catch (error: any) {
            logger.error('Failed to navigate to GCP dashboard section', error);
            throw new Error(`AWS Navigation Failure: ${error.message}`);
        }
    }

    async clickDropdown(dropdownName: string): Promise<void> {
        test.setTimeout(900 * 1000);
        await this.page.waitForLoadState('domcontentloaded');
        await this.page.waitForLoadState('networkidle');
        await this.page.setViewportSize({ width: 1620, height: 1080 });
        await this.page.evaluate(() => {
            document.body.style.transform = 'scale(0.8)';
            document.body.style.transformOrigin = '0 0';
        });
        logger.info(`Clicking dropdown context: ${dropdownName}`);
        const dropdown = this.page.getByText(dropdownName, { exact: true }).first();
        await this.page.waitForLoadState('load');
        await expect(dropdown).toBeEnabled();
        await expect(dropdown).toBeVisible();
        await dropdown.click();
        await this.page.waitForLoadState('networkidle');

    }


    async clickDropdown1(dropdownName: string): Promise<void> {
        test.setTimeout(900 * 1000);
        await this.page.waitForLoadState('domcontentloaded');
        await this.page.waitForLoadState('networkidle');
        await this.page.setViewportSize({ width: 1620, height: 1080 });
        await this.page.evaluate(() => {
            document.body.style.transform = 'scale(0.8)';
            document.body.style.transformOrigin = '0 0';
        });
        logger.info(`Clicking dropdown context: ${dropdownName}`);
        const dropdown = this.page
            .getByText(dropdownName, { exact: true })
            .filter({ visible: true })
            .first();
        await expect(dropdown).toBeVisible({ timeout: 10000 });
        await expect(dropdown).toBeEnabled({ timeout: 10000 });
        await dropdown.click();
        await this.page.waitForLoadState('networkidle');
    }

    /**
  * Handles target dashboard redirection paths safely
  */
    async clickViewButton(buttonValue: string): Promise<void> {
        logger.info(`Clicking view button context ID: ${buttonValue}`);
        const selector = commonLocators.viewButton(buttonValue);
        let targetElement = this.page.locator(selector).first();
        try {
            if (!(await targetElement.isVisible())) {
                logger.info(`Original selector not found. Attempting Angular data-page-title parsing for: ${buttonValue}`);
                const formattedTitle = buttonValue.replace(/-/g, ' ').replace(/\b\w/g, (char) => char.toUpperCase()).trim();
                const angularCard = this.page.locator(`div[data-page-title*="${formattedTitle}"]`);
                targetElement = angularCard.locator('a.btn, button').first();
            }
            await targetElement.waitFor({ state: 'attached', timeout: 5000 });
            await targetElement.scrollIntoViewIfNeeded();
            await targetElement.click({ force: true });
            await this.page.waitForLoadState('networkidle');
        } catch (error: any) {
            logger.error(`Failed to click view button "${buttonValue}". Selector: "${selector}"`, error);
            throw new Error(`Target button element actionability failure: ${error.message}`);
        }
    }

    async clickViewButton1(buttonValue: string): Promise<void> {
        logger.info(`Clicking view button context ID: ${buttonValue}`);
        const selector = commonLocators.viewButton(buttonValue);
        try {
            let targetElement = null;
            const elements = this.page.locator(selector);
            const count = await elements.count();
            logger.info(`Primary selector "${selector}" returned ${count} elements`);
            for (let i = 0; i < count; i++) {
                const element = elements.nth(i);
                if (await element.isVisible()) {
                    targetElement = element;
                    logger.info(
                        `Found visible element using primary selector at index ${i}`
                    );
                    break;
                }
            }
            if (!targetElement) {
                logger.info(
                    `Primary locator failed. Attempting Angular data-page-title lookup for "${buttonValue}"`
                );
                const formattedTitle = buttonValue.replace(/-/g, ' ').replace(/\b\w/g, char => char.toUpperCase()).trim();
                const angularCard = this.page.locator(`div[data-page-title*="${formattedTitle}"]`);
                const cardCount = await angularCard.count();
                logger.info(`Found ${cardCount} card(s) matching title "${formattedTitle}"`);
                const buttons = angularCard.locator('a.btn, button');
                const buttonCount = await buttons.count();
                logger.info(`Found ${buttonCount} button(s) inside matching card(s)`);
                for (let i = 0; i < buttonCount; i++) {
                    const button = buttons.nth(i);
                    if (await button.isVisible()) {
                        targetElement = button;
                        logger.info(`Found visible fallback button at index ${i}`);
                        break;
                    }
                }
            }
            if (!targetElement) {
                throw new Error(
                    `No visible View button found for "${buttonValue}"`
                );
            }
            await targetElement.scrollIntoViewIfNeeded();
            await targetElement.waitFor({
                state: 'visible',
                timeout: 30000
            });
            logger.info(`Clicking visible View button`);
            await targetElement.click({ force: true });
            await this.page.waitForLoadState('networkidle');
            logger.info(`Successfully clicked View button`);
        } catch (error: any) {
            logger.error(`Failed to click view button "${buttonValue}". Selector: "${selector}"`,
                error
            );
            throw new Error(`Target button element actionability failure: ${error.message}`);
        }
    }
    /**
       * Core verification checker validating rows display on screen
       */
    async verifyTableLoaded(): Promise<number> {
        test.setTimeout(900 * 1000);
        await this.page.waitForLoadState('domcontentloaded');
        await this.page.waitForLoadState('networkidle');
        await this.page.waitForLoadState('load');
        await this.page.waitForSelector(paginationLocators.tableRows);
        await expect(this.page.locator(paginationLocators.tableRows).first()).toBeVisible();
        const rowCount = await this.page.locator(paginationLocators.tableRows).count();
        logger.info(`Table row count verified: ${rowCount}`);
        expect(rowCount).toBeGreaterThan(0);
        return rowCount;
    }

    async verifyDefaultPageSize(expectedSize: string): Promise<void> {
        await expect(this.page.locator(paginationLocators.pageSizeDropdown)).toHaveValue(expectedSize);
        logger.info(`Default page size matches expected value: ${expectedSize}`);
    }

    async verifyPaginationSummary(): Promise<void> {
        await expect(this.page.locator(paginationLocators.tableSummary)).toBeVisible();
        const summaryText = await this.page.locator(paginationLocators.tableSummary).textContent();
        logger.info(`Table summary readout text: ${summaryText}`);
    }

    async getActivePageNumber(): Promise<number> {
        const activePageText = await this.page.locator(paginationLocators.activePage).textContent();
        logger.info(`Extracted active page structural number: ${activePageText}`);
        return Number(activePageText);
    }

    async verifyActivePage(expectedPage: string): Promise<number> {
        await expect(this.page.locator(paginationLocators.activePage)).toHaveText(expectedPage);
        const activePage = await this.page.locator(paginationLocators.activePage).textContent();
        logger.info(`Active target pagination matching matrix: ${activePage}`);
        return Number(activePage);
    }

    async clickNextPage(): Promise<void> {
        logger.info('Executing click interaction on Next button');
        await this.page.locator(paginationLocators.nextButton).first().click();
    }

    async clickPreviousPage(): Promise<void> {
        logger.info('Executing click interaction on Previous button');
        await this.page.locator(paginationLocators.previousButton).click();
    }

    async clickPageNumber(pageNumber: string): Promise<void> {
        logger.info(`Navigating directly to absolute page element: ${pageNumber}`);
        await this.page.locator(paginationLocators.pageNumber(pageNumber)).click();
    }

    async clickFirstPage(): Promise<void> {
        logger.info('Navigating to first index bounding index');
        await this.page.locator(paginationLocators.firstButton).click();
        await this.page.waitForLoadState('networkidle');
    }

    /**
   * Loops through dynamic multi-page layouts safely without hard delays
   */
    async clickLastPage(): Promise<void> {
        logger.info('Navigating to the last page by clicking next until finished');
        const lastButton = this.page.locator(paginationLocators.lastButton);
        while (await lastButton.isVisible()) {
            await lastButton.click();
            await this.page.waitForTimeout(6000);
            await this.page.waitForLoadState('networkidle');
        }
        logger.info('Reached the final page; next button is no longer visible');
    }


    async verifyPreviousNotVisible(): Promise<void> {
        await expect(this.page.locator(paginationLocators.previousButton)).not.toBeVisible();
        logger.info('Verified previous button is hidden as expected.');
    }

    async verifyNextDisable(): Promise<void> {
        await expect(this.page.locator(paginationLocators.nextButton)).not.toBeVisible();
        logger.info('Verified next button state is disabled.');
    }

    async verifyNextEnabled(): Promise<void> {
        await expect(this.page.locator(paginationLocators.nextButton)).toBeEnabled();
        logger.info('Verified next button state is active.');
    }

    async verifyPaginationAlignment(): Promise<void> {
        await expect(this.page.locator(paginationLocators.paginationAlignment)).toBeVisible();
        logger.info('Pagination positioning element layout matches design guidelines.');
    }

    async selectPageSize(pageSize: string): Promise<void> {
        logger.info(`Changing layout density constraint option to: ${pageSize}`);
        await this.page.locator(paginationLocators.pageSizeDropdown).selectOption(pageSize);
        await this.page.waitForLoadState('networkidle');
    }

    async openFilter(): Promise<void> {
        logger.info('Opening query matrix filter dropdown');
        await this.page.locator(paginationLocators.filterButton).click();
        await expect(this.page.locator(paginationLocators.filterOverlay)).toBeVisible();
    }

    async selectFilterCategory(filterName: string): Promise<void> {
        logger.info(`Filtering on operational property key: ${filterName}`);
        await this.page.locator(paginationLocators.filterCategory(filterName)).first().click();
    }

    async selectFilterCheckbox(value: string): Promise<void> {
        logger.info(`Selecting categorical matching identifier flag: ${value}`);
        await expect(this.page.locator(paginationLocators.filterCheckboxes(value)).first()).toBeVisible({ timeout: 30000 });
        await this.page.locator(paginationLocators.filterCheckboxes(value)).first().click();
    }

    /**
    * Commits layout filters and awaits table recalculations instantly
    */
    async applyFilter(): Promise<void> {
        logger.info('Dispatching active structural layout query filters');
        await expect(this.page.locator(paginationLocators.applyFilterButton).first()).toBeVisible({ timeout: 30000 });
        await this.page.locator(paginationLocators.applyFilterButton).click();
        await this.page.waitForLoadState('networkidle');
        await this.page.waitForTimeout(6000);

    }

    async clearFilterButton(): Promise<void> {
        await this.page.waitForTimeout(6000);
        logger.info('Resetting current search constraints back to default parameters');
        await expect(this.page.locator(paginationLocators.clearFilterButton).first()).toBeVisible({ timeout: 30000 });
        await this.page.locator(paginationLocators.clearFilterButton).click();
        await this.page.waitForLoadState('networkidle');
    }

    async closeFilter(): Promise<void> {
        logger.info('Dismissing query filtering element layout container overlay');
        const closeBtn = this.page.locator(paginationLocators.closeFilterButton).first();
        if (await closeBtn.isVisible()) {
            await closeBtn.click();
        }
    }

    async clickColumnHeader(columnName: string): Promise<void> {
        logger.info(`Toggling order transformation index parameters on column header: ${columnName}`);
        try {
            test.setTimeout(500 * 500);
            await this.page.locator(paginationLocators.sortIcon(columnName)).first().click({ force: true });
            await this.page.waitForLoadState('networkidle');
        } catch (error) {
            logger.error(`Critical layout interface processing exception on: ${columnName}`, error);
            throw error;
        }
    }

    async selectFilterColumnDropdown(filterName: string): Promise<void> {
        logger.info(`Selecting alternate dropdown schema: ${filterName}`);
        await this.page.locator(paginationLocators.dropdownfilter).click();
        await this.page.locator(paginationLocators.filterCheckbox(filterName)).click();
    }

    async clickSaveFilter(): Promise<void> {
        logger.info('Persisting active filtered criteria');
        await this.page.locator(paginationLocators.saveFilterButton).click();
        await this.page.waitForTimeout(3000);
    }

    async clearFilter(): Promise<void> {
        logger.info('Cleaning and rolling back filtering state context');
        const feedbackPopup = this.page.locator('app-user-feedback');
        if (await feedbackPopup.count() > 0) {
            console.log('Feedback widget detected.');
            await this.page.evaluate(() => {
                const feedback = document.querySelector('app-user-feedback');
                if (feedback) {
                    (feedback as HTMLElement).style.display = 'none';
                }
            });
            console.log('Feedback widget hidden.');
        }
        const clearBtn = this.page.locator(paginationLocators.clearFilterButton).last();
        await clearBtn.waitFor({
            state: 'visible',
            timeout: 10000
        });
        await clearBtn.scrollIntoViewIfNeeded();

        console.log(`
=================================================
CLEAR FILTER VALIDATION
=================================================
Button Visible : ${await clearBtn.isVisible()}
Button Enabled : ${await clearBtn.isEnabled()}
=================================================
`);
        await clearBtn.evaluate((button: HTMLElement) => {
            button.click();
        });
        console.log('Clear All button clicked successfully.');
        await this.page.waitForLoadState('networkidle');
        console.log(' Filters cleared successfully.');
    }

    async getTableRowCount(): Promise<number> {
        return await this.page.locator(paginationLocators.tableRows).count();
    }

    async setScreenSize(width: number, height: number): Promise<void> {
        await this.page.setViewportSize({ width, height });
        logger.info(`Adaptive screen layout shifted: ${width}x${height}`);
    }
}
