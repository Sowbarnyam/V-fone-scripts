// ====================================================================
// PURPOSE: Handles table-level interactions (sorting, toggle, header UX)
// UPDATED: Fully aligned with TC_SORT_001 → TC_SORT_019
// ====================================================================

import { expect, Page } from '@playwright/test';
import { Pagination } from '../pages/DashboardPage';
import { testDataParams } from '../locators/dashboardLocators';

export class TableInteractionPage extends Pagination {
    constructor(page: Page) {
        super(page);
    }

    // ===================== HELPERS =====================

    private sortAsc = (data: string[]) => [...data].sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' }));
    private sortDesc = (data: string[]) => [...this.sortAsc(data)].reverse();
    private parseNumber(value: string): number {
        return Number(value.replace(/[^0-9.-]+/g, ''));
    }
    private getHeader(columnName: string) {
        return this.page.locator('th').filter({ hasText: columnName }).first();
    }
    private logStart(title: string) {
        console.log(`START VALIDATION: ${title}`);
    }
    private logEnd(title: string) {
        console.log(`END VALIDATION: ${title}`);
    }

    // ===================== TC_SORT_001 =====================

    async verifyAscendingSort(columnName: string) {
        this.logStart(`ASC SORT - ${columnName}`);
        const before = await this.getColumnData(columnName);
        console.log('BEFORE:', before);
        await this.clickColumnHeader(columnName);
        const after = await this.getColumnData(columnName);
        console.log('AFTER ASC:', after);
        for (let i = 0; i < after.length - 1; i++) {
            const current = after[i];
            const next = after[i + 1];
            if (current.localeCompare(next) > 0) {
                console.error(` ${current} > ${next}`);
            }
        }
        await this.verifyPaginationSorting(columnName, 'asc');
        this.logEnd(`ASC SORT - ${columnName}`);
    }

    // ===================== TC_SORT_002 =====================

    async verifyDescendingSort(columnName: string) {
        this.logStart(`DESC SORT - ${columnName}`);
        const before = await this.getColumnData(columnName);
        console.log('BEFORE:', before);
        await this.clickColumnHeader(columnName);
        await this.clickColumnHeader(columnName);
        const after = await this.getColumnData(columnName);
        console.log('AFTER DESC:', after);
        for (let i = 0; i < after.length - 1; i++) {
            if (after[i].localeCompare(after[i + 1]) < 0) {
                console.error(`${after[i]} < ${after[i + 1]}`);
            }
        }
        await this.verifyPaginationSorting(columnName, 'desc');
        this.logEnd(`DESC SORT - ${columnName}`);
    }

    // ===================== TC_SORT_003 =====================

    async verifyToggleSortingCycle(columnName: string) {
        this.logStart(`TOGGLE SORT - ${columnName}`);
        const def = await this.getColumnData(columnName);
        console.log('DEFAULT:', def);
        await this.clickColumnHeader(columnName);
        console.log('ASC:', await this.getColumnData(columnName));
        await this.clickColumnHeader(columnName);
        console.log('DESC:', await this.getColumnData(columnName));
        await this.clickColumnHeader(columnName);
        console.log('RESET:', await this.getColumnData(columnName));
        this.logEnd(`TOGGLE SORT - ${columnName}`);
    }

    // ===================== TC_SORT_004 =====================

    async verifyNumericSorting(columnName: string) {
        this.logStart(`NUMERIC SORT VALIDATION`);
        console.log('BEFORE:', (await this.getColumnData(columnName)).map(this.parseNumber));
        await this.clickColumnHeader(columnName);
        console.log('ASC:', (await this.getColumnData(columnName)).map(this.parseNumber));
        await this.clickColumnHeader(columnName);
        console.log('DESC:', (await this.getColumnData(columnName)).map(this.parseNumber));
        this.logEnd(`NUMERIC SORT VALIDATION`);
    }

    // ===================== TC_SORT_005 =====================

    async verifyCurrencySorting(columnName: string) {
        this.logStart(`CURRENCY SORT VALIDATION`);
        await this.verifyNumericSorting(columnName);
        this.logEnd(`CURRENCY SORT VALIDATION`);
    }

    // ===================== TC_SORT_006 =====================

    async verifyPaginationSorting(columnName: string, type: 'asc' | 'desc') {
        console.log(' PAGINATION Sorting VALIDATION');
        console.log('Page1:', await this.getColumnData(columnName));
        await this.clickNextPage();
        console.log('Page2:', await this.getColumnData(columnName));
        await this.clickPreviousPage();
    }

    // ===================== TC_SORT_007 =====================

    async verifySortingWithFilterRetention(columnName: string, category: string, value: string) {
        this.logStart(`FILTER SORT VALIDATION`);
        await this.openFilter();
        await this.selectFilterCategory(category);
        await this.selectFilterCheckbox(value);
        await this.applyFilter();
        console.log('Before:', await this.getColumnData(columnName));
        await this.clickColumnHeader(columnName);
        console.log('After:', await this.getColumnData(columnName));
        await this.clearFilter();
        this.logEnd(`FILTER SORT VALIDATION`);
    }

    // ===================== TC_SORT_008 =====================

    async verifyEmptySorting(columnName: string) {
        this.logStart(`EMPTY DATASET VALIDATION`);
        console.log('Before:', await this.getColumnData(columnName));
        await this.clickColumnHeader(columnName);
        console.log('After:', await this.getColumnData(columnName));
        this.logEnd(`EMPTY DATASET VALIDATION`);
    }

    // ===================== TC_SORT_009 =====================

    async verifySortingIconUpdatesCorrectly(columnName: string) {
        this.logStart(`ICON VALIDATION`);
        const h = this.getHeader(columnName);
        console.log('Before:', await h.getAttribute('aria-sort'));
        await h.click();
        console.log('ASC:', await h.getAttribute('aria-sort'));
        await h.click();
        console.log('DESC:', await h.getAttribute('aria-sort'));
        await h.click();
        console.log('RESET:', await h.getAttribute('aria-sort'));
        this.logEnd(`ICON VALIDATION`);
    }

    // ===================== TC_SORT_010 =====================

    async verifyActiveColumnHighlight(col1: string, col2: string) {
        this.logStart(`COLUMN HIGHLIGHT`);
        const h1 = this.getHeader(col1);
        const h2 = this.getHeader(col2);
        await h1.click();
        console.log(`Clicked Column 1: ${col1}`);
        console.log('Column 1 Active Attr:', await h1.getAttribute('aria-sort'));
        await h2.click();
        console.log(`Switched to Column 2: ${col2}`);
        console.log('Column 2 Active Attr:', await h2.getAttribute('aria-sort'));
        this.logEnd(`COLUMN HIGHLIGHT`);
    }

    // ===================== TC_SORT_011 =====================

    async verifyNoFlickeringDuringSorting(columnName: string) {
        this.logStart(`FLICKER CHECK`);
        const before = await this.getTableRowCount();
        console.log('ROW COUNT BEFORE:', before);
        await this.clickColumnHeader(columnName);
        const after = await this.getTableRowCount();
        console.log('ROW COUNT AFTER:', after);
        const changed = before !== after;
        console.log('Flicker Detected?', changed ? 'YES ' : 'NO ');
        expect(before).toBe(after);
        this.logEnd(`FLICKER CHECK`);
    }

    // ===================== TC_SORT_012 =====================

    async verifyColumnAlignmentAfterSorting(columnName: string) {
        this.logStart(`ALIGNMENT CHECK`);
        const header = this.getHeader(columnName);
        const before = await header.evaluate(el =>
            window.getComputedStyle(el).textAlign
        );
        console.log('ALIGNMENT BEFORE:', before);
        await this.clickColumnHeader(columnName);
        const after = await header.evaluate(el =>
            window.getComputedStyle(el).textAlign
        );
        console.log('ALIGNMENT AFTER:', after);
        console.log('Alignment Same?', before === after ? 'YES ' : 'NO ');
        expect(before).toBe(after);
        this.logEnd(`ALIGNMENT CHECK`);
    }


    // ===================== TC_SORT_013 =====================

    async verifyLoaderVisibleDuringSorting(columnName: string) {
        this.logStart(`LOADER CHECK`);
        const loader = this.page.locator('.loader, .spinner');
        await this.clickColumnHeader(columnName);
        let visible = false;
        try {
            await loader.first().waitFor({ state: 'visible', timeout: 2000 });
            visible = true;
        } catch { }
        console.log('Loader Visible?', visible ? 'YES ' : 'NO ');
        if (visible) {
            try {
                await loader.first().waitFor({ state: 'hidden', timeout: 5000 });
                console.log('Loader Hidden ');
            } catch {
                console.warn('Loader did not hide');
            }
        }
        this.logEnd(`LOADER CHECK`);
    }

    // ===================== TC_SORT_014 =====================

    async verifySortingWithNullValues(columnName: string) {
        this.logStart(`NULL`);
        const beforeData = await this.getColumnData(columnName);
        console.log('Before:', beforeData.map(v => this.formatValue(v)));
        await this.clickColumnHeader(columnName);
        const data = await this.getColumnData(columnName);
        console.log('After:', data.map(v => this.formatValue(v)));
        const nullCount = data.filter(v => v === null || v === undefined || v === '' || v === '--').length;
        console.log('Null count:', nullCount);
        this.logEnd(`NULL`);
    }

    formatValue(value: any): string {
        if (value === null) return 'NULL';
        if (value === undefined) return 'UNDEFINED';
        if (value === '') return 'EMPTY STRING';
        if (value === '--') return 'DASH(-- )';
        return value;
    }


    // ===================== TC_SORT_015 =====================
    printFormattedRows(data: any[]) {
        data.slice(0, 10).forEach((value, index) => {
            console.log(`Row ${index + 1}:`, this.formatValue(value));
        });
    }
    async verifySortingWithMixedDataTypes(columnName: string) {
        this.logStart(`MIXED DATA TYPES - ${columnName}`);
        const before = await this.getColumnData(columnName);
        console.log('BEFORE DATA (Top 10 rows):');
        this.printFormattedRows(before);
        await this.clickColumnHeader(columnName);
        const after = await this.getColumnData(columnName);
        console.log('AFTER SORT DATA (Top 10 rows):');
        this.printFormattedRows(after);
        console.log(
            'CHANGED?',
            JSON.stringify(before) !== JSON.stringify(after)
        );
        expect(before).not.toBeNull();
        expect(after).not.toBeNull();
        this.logEnd(`MIXED DATA TYPES - ${columnName}`);
    }


    // ===================== TC_SORT_016 =====================

    async verifySortingWhenApiFails(columnName: string) {
        this.logStart(`API FAIL`);
        await this.page.route('**/*sort*', r => r.fulfill({ status: 500 }));
        const before = await this.getColumnData(columnName);
        await this.clickColumnHeader(columnName);
        const after = await this.getColumnData(columnName);
        this.logEnd(`API FAIL`);
    }

    // ===================== TC_SORT_017 =====================

    async verifyRapidSortingClicks(columnName: string) {
        this.logStart(`RAPID CLICK SORT - ${columnName}`);
        for (let i = 0; i < 5; i++) {
            console.log(` Click ${i + 1}`);
            await this.clickColumnHeader(columnName);
            const data = await this.getColumnData(columnName);
            console.log(`DATA AFTER CLICK ${i + 1}:`, data);
        }
        const finalData = await this.getColumnData(columnName);
        console.log('FINAL DATA:', finalData);
        expect(finalData.length).toBeGreaterThan(0);
        this.logEnd(`RAPID CLICK SORT - ${columnName}`);
    }

    // ===================== TC_SORT_018 =====================

    async verifySortingAfterDataRefresh(columnName: string) {
        this.logStart(`REFRESH`);
        await this.clickColumnHeader(columnName);
        await this.page.reload();
        await this.clickDropdown(testDataParams.costFlow.dropdownTable);
        console.log('After:', await this.getColumnData(columnName));
        this.logEnd(`REFRESH`);
    }

    async verifySortingAfterDataRefreshGCP(columnName: string) {
        this.logStart(`REFRESH`);
        await this.clickColumnHeader(columnName);
        await this.page.reload();
        await this.clickDropdown(testDataParams.costFlow.dropdown);
        console.log('After:', await this.getColumnData(columnName));
        this.logEnd(`REFRESH`);
    }

    async verifySortingAfterDataRefreshAzure(columnName: string) {
        this.logStart(`REFRESH`);
        await this.clickColumnHeader(columnName);
        await this.page.reload();
        await this.clickDropdown(testDataParams.costFlow.dropdownTableAzure);
        console.log('After:', await this.getColumnData(columnName));
        this.logEnd(`REFRESH`);
    }

    // ===================== TC_SORT_019 =====================

    async verifySortingWithDuplicateValues(columnName: string) {
        this.logStart(`DUPLICATE CHECK`);
        const data = await this.getColumnData(columnName);
        console.log('DATA:', data);
        const hasDuplicates = new Set(data).size < data.length;
        if (hasDuplicates) {
            console.log(' Duplicates found in dataset');
        } else {
            console.warn(' No duplicates found in dataset');
        }
        this.logEnd(`DUPLICATE CHECK`);
    }

    async verifyTableLoadPerformance(columnName: string) {
        this.logStart(`PERFORMANCE CHECK - ${columnName}`);
        const startTime = Date.now();
        await this.clickColumnHeader(columnName);
        const loader = this.page.locator('.loader, .spinner');
        try {
            await loader.first().waitFor({ state: 'visible', timeout: 2000 });
            await loader.first().waitFor({ state: 'hidden', timeout: 10000 });
        } catch {
            console.log('No loader detected, proceeding...');
        }
        const rowCount = await this.getTableRowCount();
        const endTime = Date.now();
        const durationMs = endTime - startTime;
        const durationSec = (durationMs / 1000).toFixed(2);
        console.log(`Table loaded successfully`);
        console.log(`Rows Loaded: ${rowCount}`);
        console.log(`Load Time: ${durationSec} seconds`);
        this.logEnd(`PERFORMANCE CHECK - ${columnName}`);
    }
}