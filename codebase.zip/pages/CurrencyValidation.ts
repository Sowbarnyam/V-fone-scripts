import { type Page } from '@playwright/test';
import { logger } from '../utils/logger';
import { Pagination } from './DashboardPage';
import { CurrencyPage } from './Currency';

export class CurrencyValidationPage extends Pagination {
    private currencyPage: CurrencyPage;

    constructor(protected page: Page) {
        super(page);
        this.currencyPage = new CurrencyPage(page);
    }

    async verifySymbolValidation(columnNames: string[], currencySymbol: string): Promise<void> {
        logger.info('-------Verifying Symbol Validation--------');
        await this.verifyTableLoaded();
        await this.verifyDefaultPageSize('10');
        await this.verifyPaginationSummary();
        for (const columnName of columnNames) {
            logger.info(`Validating currency format for column: ${columnName}`);
            await this.verifyCurrencyFormat(columnName, currencySymbol);
            await this.clickLastPage();
            await this.clickFirstPage();
        }
        logger.info('-------Validated Symbol Validation Successfully--------');
    }

    async verifyCurrencyThousandFormatting(): Promise<void> {
        logger.info('--------Verifying Currency Formatting ---------');
        await this.verifyTableLoaded();
        await this.verifyDefaultPageSize('10');
        await this.verifyPaginationSummary();
        await this.currencyPage.validateThousandsSeparatorAcrossAllRows();
        logger.info('--------- Validate Currency Formatting Workflow ---------');
    }


    async verifyLargeValueReadabilityWorkflow(columnNames: string[]): Promise<void> {
        logger.info(`Starting Large Value Validation for columns: ${columnNames.join(', ')}`);
        for (const columnName of columnNames) {
            await this.currencyPage.validateTableState(columnName);
        }
        await this.clickNextPage();
        await this.page.waitForLoadState('networkidle');
        for (const columnName of columnNames) {
            await this.currencyPage.validateTableState(columnName);
        }
        await this.clickLastPage();
        await this.page.waitForLoadState('networkidle');
        for (const columnName of columnNames) {
            await this.currencyPage.validateTableState(columnName);
        }
        await this.clickFirstPage();
        await this.page.waitForLoadState('networkidle');
        logger.info('Completed Large Value Validation across all pages and columns.');
    }


    async verifySymbolAlignmentWorkflow(columnNames: string[]): Promise<void> {
        logger.info('----------Verifying Multi-Page Symbol Alignment----------');
        logger.info(`Target columns: ${columnNames.join(', ')}`);
        logger.info('Auditing Symbol Alignment on Page 1 (Initial View)...');
        for (const columnName of columnNames) {
            await this.currencyPage.verifySymbolAlignment(columnName);
        }
        logger.info('Navigating to Last Page for alignment validation...');
        await this.clickLastPage();
        await this.page.waitForLoadState('networkidle');
        for (const columnName of columnNames) {
            await this.currencyPage.verifySymbolAlignment(columnName);
        }
        logger.info('----------Validated Symbol Alignment Across All Pages Successfully----------');
    }
}


