// ====================================================================
// PURPOSE: Stores CSS, XPath, and dynamic selectors for the AWS Dashboard.
// USAGE:   Imported by page classes to interact with UI components.
// ====================================================================

export const dashboardLocators = {
    vCloudSmartTab: '//*[@id="nav-vcloudsmart-tab"]',
    awsCard: 'a:has(p:text-is("Amazon Web Services"))',
    gcpCard: 'a:has(p:text-is("Google Cloud Platform"))',
    azureCard: 'a:has(p:text-is("Microsoft Azure"))',
    oracleCard: 'a:has(p:text-is("Oracle Cloud"))'
};

export const commonLocators = {
    dropdownByText: (text: string) => `text=${text}`,
    viewButton: (value: string) => `a[data-test*="${value}"], a[href*="${value}"], button[data-test*="${value}"]`,
};

export const paginationLocators = {
    // Core Grid Structure

    tableRows: '.table-responsive table tbody tr',
    tableSummary: 'p:has-text("Page")',
    pageSizeDropdown: 'app-pagination select',
    paginationContainer: 'nav[aria-label="Page navigation"]',
    paginationAlignment: '.pagination',
    tableHeader: (columnName: string) => `th:has-text("${columnName}")`,
    sortIcon: (columnName: string) => `th:has-text("${columnName}") svg`,
    searchInput: 'input[type="search"]',

    // Control Elements

    pageNavigation: { role: 'navigation' as const, name: /page navigation/i },
    nextButton: '.pagination li:nth-last-child(2) a',
    previousButton: '.pagination li:nth-child(2) a',
    firstButton: '[tooltip="First page"]',
    lastButton: 'li[tooltip="Last page"]',
    activePage: '.page-item.active .page-link',
    pageNumber: (page: string) => `.page-link:text-is("${page}")`,

    // Filter Elements

    dropdownfilter: '//*[@id="column-select-container"]/h5/app-vficon',
    filterCheckbox: (filterName: string) => `input[type="checkbox"][name="${filterName}"]`,
    saveFilterButton: 'button:has-text("Save")',
    clearFilterIcon: 'svg[viewBox="0 0 192 192"]',
    appliedFilterChip: '.ng-star-inserted',
    filterButton: '#filterButton',
    filterOverlay: '.filter-overlay.show',
    filterCategory: (filterName: string) => `div.resources:has-text("${filterName}")`,
    filterCheckboxes: (value: string) => `//label[contains(text(), '${value}')]/preceding-sibling::input[@type='checkbox']`,
    applyFilterButton: "//button[contains(.,'Apply')]",
    clearFilterButton: "button:has-text('Clear')",
    closeFilterButton: "button:has-text('Close')",


    currencyDropdown: 'button:has-text("USD")',
    currencyOption: (currency: string) => `//button[contains(text(),"${currency}")]`,
    currencyColumnValues: (columnName: string) => `xpath=//div[contains(@class, 'table-responsive')]//table//thead//th[contains(.,'${columnName}')]/ancestor::table//tbody//tr/td[count(//div[contains(@class, 'table-responsive')]//table//thead//th[contains(.,'${columnName}')]/preceding-sibling::th)+1]`,
    dateColumnValues: (columnName: string) => `xpath=//div[contains(@class, 'table-responsive')]//table//thead//th[contains(.,'${columnName}')]/ancestor::table//tbody//tr/td[count(//div[contains(@class, 'table-responsive')]//table//thead//th[contains(.,'${columnName}')]/preceding-sibling::th)+1]`,
    graphTableData: (columnName: string) =>
        `xpath=//*[local-name()='svg']//*[local-name()='text'][contains(., '${columnName}')]`,
    tableData: (columnName: string) =>
        `xpath=//th[descendant::p[contains(., '${columnName}')]]/ancestor::table//tr[last()]/td[count(//th[descendant::p[contains(., '${columnName}')]]/preceding-sibling::th) + 1]`,
    lastMonth: 'text=Last Month',

    costValidationColumns: [
        'Total Cost',
        'Actual Cost',
        'Operations & Security',
        'PCS Enabler Cost',
        'Account Enablement Fee '
    ]
};

export const testDataParams = {
    ec2Flow: {
        dropdownAsset: 'Asset Inventory',
        viewButton: 'ec2-instances',
        dropdownTable: 'Instances Table',
        columnsToSort: ['Name', 'Type'] as const,
        dateColumn: 'Launch Time',
        apiKeyWord: 'ec2',
        viewButtonGcp: 'compute-instances',
        dropdownTableGcp: 'Compute Instance Table',
        columnsToSortGcp: ['Instance Name', 'Instance ID'] as const,
        apiKeyWordGcp: 'compute',
        dropdownTableOracle: 'Instance Details',
        apiKeyWordOracle: 'instance',
        columnsToSortOracle: ['Name', 'Region'] as const,
    },

    costFlow: {
        dropdownCloud: 'Cloud Recommendations',
        viewButton: 'cost-by-on-demand-compute',
        dropdownTable: 'On-Demand Compute Spend Table',
        dropdown: 'Detailed Data',
        dropdownView: 'Extended Support Charge Recommendations',
        dropdownView1: 'extended-support-charge-recommendations',
        columnsToSort: ['Account Name', 'Region'] as const,
        columnsToSorting: ['Account Name', 'Region', 'Product', 'Instance Family'] as const,
        columnsToSortingGcp: ['Project ID', 'Project Name', 'Cost Center', 'Local Market', 'Usage Type'] as const,
        numericColumn: 'Account ID',
        numericColumnGcp: 'Usage Month',
        currencyColumnGcp: ' Total Cost',
        currencyColumn: 'Actual Cost',
        currencySymbol: '$',
        apiKeyWord: 'compute',
        viewButtonAzure: 'security',
        dropdownTableAzure: 'Recommendations by Count (Security)',
        columnsToSortAzure: ['Service', 'Active Recommendations'] as const,
        numericColumnAzure: 'Active Recommendations',
        apiKeywordAzure: 'recommendations'
    },

    currencyFlow: {
        dropdownCost: 'Cost & Billing',
        viewButton: 'charge-analysis-sams',
        viewButtonAzure: 'charge-analysis',
        dropdownTable: 'Invoice Table',
        currencyColumn: 'Actual Cost',
        currencyColumn1: 'Usage',
        currencyColumn2: 'Discounted Usage',
        currencyColumn3: 'Credit',
        currencyColumn4: 'Refund',
        currencySymbol: '$',
        currencySymbol1: '£',
        currencySymbol2: '€',
        dropdownOracle: 'Recommendations',
        viewButtonOracle: 'performance',
        dropdownTableOracle: 'Recommendation Details by Performance',
        currencyColumnOracle: 'Estimated Cost Saving',

    },

    currency: {
        currencyColumn1: 'Total Cost',
        currencySymbol: '$',
    }
};






