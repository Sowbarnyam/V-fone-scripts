export const loginLocators = {
    emailInput: 'input[placeholder*="vodafone"]',
    continueBtn: 'input[value="Continue"]',
    portalTitle: 'h1:text("PCS Portal")',
    authEmailInput: 'input[type="email"]',
    authNextBtn: 'input[type="submit"]',
    authPassword: 'input[type="password"]',
    authYesBtn: 'input[value="Yes"]',
    authUrl: /microsoftonline\.com/, 
    dashboardUrl: '**/dashboard**'
};
