export const currencyLocators = {
    financeText: '//*[@id="vcloudsmart"]/app-vcs-home-section/div[1]/div[2]/button[5]', 
    chargeAnalysisTable: '//table',
    currencyCells: '//table/tbody/tr/td[contains(text(),"$")]',
    actualCostColumn: '//table/tbody/tr/td[2]',
    usageColumn: '//table/tbody/tr/td[3]',
    discountedUsageColumn: '//table/tbody/tr/td[4]',
    creditColumn: '//table/tbody/tr/td[5]',
    tooltip: '.custom-table-tooltip',
};