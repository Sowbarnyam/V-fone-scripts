import { test, expect } from '@playwright/test';
import { Pagination } from '../pages/DashboardPage';
import { ENV } from '../utils/env';
import { testDataParams } from '../locators/dashboardLocators';

test.describe('Pagination Validation', () => {
    let dashboardPage: Pagination;

    test.beforeEach(async ({ page }) => {
        dashboardPage = new Pagination(page);

        await test.step('WHEN user launches Vodafone dashboard', async () => {
            await page.goto(ENV.DASHBOARD_URL);
            await expect(page).toHaveURL(/dashboard/);
        });
    }); 
 test('Filter Validation', async () => {
        const parameter = testDataParams.currencyFlow;

        await test.step('WHEN user navigates to Charge Analysis Page', async () => {
            await dashboardPage.navigateToAWS();
            await dashboardPage.clickDropdown(parameter.dropdownCost);
            await dashboardPage.clickViewButton(parameter.viewButton);
            await dashboardPage.waitForPageReady();
            await dashboardPage.clickDropdown(parameter.dropdownTable);
        });

        await test.step('THEN verify table loaded with default Pagination', async () => {
            await dashboardPage.verifyTableLoadedValidation();
        });

      

        await test.step('AND verify Filter Validation and Performance', async () => {
            await dashboardPage.applyFiltersOneByOne();
        })

    });
});