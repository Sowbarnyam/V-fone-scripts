import { test, expect } from '@playwright/test';
import { runBigQuery } from '../../utils/bigquery-helper';
import { Pagination } from '../../pages/DashboardPage';
import { testDataParams } from '../../locators/dashboardLocators';
import { ENV } from '../../utils/env';
import { buildHtmlReport } from '../../utils/bigqueryhtml';
import fs from 'fs';

const periods = ['LastMonth', 'ThisMonth', 'LastYear', 'YearToDate', 'FYTD', 'LastFY'] as const;

const filterMap: Record<string, string> = {
    LastMonth: 'Last Month',
    ThisMonth: 'This Month',
    LastYear: 'Last Year',
    YearToDate: 'Year to Date',
    FYTD: 'FYTD',
    LastFY: 'Last FY'
};

const bigqueryTotals: Record<string, any> = {};
function formatCompactUSD(value: number): string {
    if (value >= 1_000_000) {
        return `$${(value / 1_000_000).toFixed(2)}M`;
    }
    if (value >= 1_000) {
        return `$${(value / 1_000).toFixed(2)}K`;
    }
    return `$${value.toFixed(2)}`;
}

test.beforeAll(async () => {
    for (const period of periods) {
        const data = await runBigQuery(period);
        bigqueryTotals[period] = {
            pcs: Number(data.Value20_PCS_Enabler_Cost || 0),
            mgmt: Number(data.Value21_Mgmt_Fee || 0),
            unblended: Number(data.Value10_line_item_unblended_cost || 0),
            annual: Number(data.Value22_Annual_Account_Fee || 0),
            baseline: Number(data.Value23_baseline_q_consumption || 0)
        };

        console.log(`\n============ BIGQUERY DATA LOADED : ${period} ============`);
        console.table(bigqueryTotals[period]);
        console.log('PCS Enabler Cost(BIGQUERY-PCS_Enabler_Cost):', formatCompactUSD(bigqueryTotals[period].pcs), '| RAW:', bigqueryTotals[period].pcs);
        console.log('Operations & Security(BIGQUERY-Mgmt_Fee):', formatCompactUSD(bigqueryTotals[period].mgmt), '| RAW:', bigqueryTotals[period].mgmt);
        console.log('Actual Cost(BIGQUERY-line_item_unblended_cost):', formatCompactUSD(bigqueryTotals[period].unblended), '| RAW:', bigqueryTotals[period].unblended);
        console.log('Account Enablement Fee(BIGQUERY-Annual_Account_Fee):', formatCompactUSD(bigqueryTotals[period].annual), '| RAW:', bigqueryTotals[period].annual);
        console.log('Baseline Q Consumption(BIGQUERY-Baseline_Q_Consumption):', formatCompactUSD(bigqueryTotals[period].baseline), '| RAW:', bigqueryTotals[period].baseline);
        console.log(`\n=========================================`);
    }
});
function parseCurrency(value: string | null): number {
    if (!value) return 0;
    value = value.replace(/[$,]/g, '').trim();
    if (value.includes('M')) {
        return parseFloat(value) * 1_000_000;
    }
    if (value.includes('K')) {
        return parseFloat(value) * 1_000;
    }
    return parseFloat(value);
}

const tableData = (columnName: string) => `xpath=//th[descendant::p[contains(., '${columnName}')]]
      /ancestor::table
      //tr[last()]
      /td[count(//th[descendant::p[contains(., '${columnName}')]]/preceding-sibling::th)+1]`;

test('Validate BigQuery vs UI', async ({ page }, testInfo) => {
    const dashboardPage = new Pagination(page);
    const parameter = testDataParams.currencyFlow;
    await page.goto(ENV.DASHBOARD_URL);
    await expect(page).toHaveURL(/dashboard/);
    await dashboardPage.navigateToAWS();
    await dashboardPage.clickDropdown(parameter.dropdownCost);
    await dashboardPage.clickViewButton(parameter.viewButton);
    await dashboardPage.waitForPageReady();
    await dashboardPage.clickDropdown(parameter.dropdownTable);
    await dashboardPage.waitForPageReady();
    await dashboardPage.verifyTableLoadedValidation();
    const reportRows: any[] = [];
    const failedColumns: string[] = [];
    for (const period of periods) {
        console.log(`\n==================== VALIDATING ${period} ====================`);
        await dashboardPage.openFilter();
        await page.click(`text=${filterMap[period]}`);
        await dashboardPage.applyFilter();
        await dashboardPage.verifyTableLoaded();

        const uiTotals = {
            pcs: parseCurrency(await page.locator(tableData('PCS Enabler Cost')).textContent()),
            mgmt: parseCurrency(await page.locator(tableData('Operations & Security')).textContent()),
            unblended: parseCurrency(await page.locator(tableData('Actual Cost')).textContent()),
            annual: parseCurrency(await page.locator(tableData('Account Enablement Fee')).textContent()),
            baseline: parseCurrency(await page.locator(tableData('Baseline Q Consumption')).textContent())
        };
        const bq = bigqueryTotals[period];
        console.log(`\n============ ${period} BIGQUERY TOTAL VALIDATION ============`);
        console.log('PCS Enabler Cost(BIGQUERY):', formatCompactUSD(bq.pcs), '| RAW:', bq.pcs);
        console.log('Operations & Security(BIGQUERY):', formatCompactUSD(bq.mgmt), '| RAW:', bq.mgmt);
        console.log('Actual Cost(BIGQUERY):', formatCompactUSD(bq.unblended), '| RAW:', bq.unblended);
        console.log('Account Enablement Fee(BIGQUERY):', formatCompactUSD(bq.annual), '| RAW:', bq.annual);
        console.log('Baseline Q Consumption(BIGQUERY):', formatCompactUSD(bq.baseline), '| RAW:', bq.baseline);

        console.log(`\n============ ${period} UI TOTAL VALIDATION ============`);
        console.log('PCS Enabler Cost(UI):', formatCompactUSD(uiTotals.pcs), '| RAW:', uiTotals.pcs.toFixed(2));
        console.log('Operations & Security(UI):', formatCompactUSD(uiTotals.mgmt), '| RAW:', uiTotals.mgmt.toFixed(2));
        console.log('Actual Cost(UI):', formatCompactUSD(uiTotals.unblended), '| RAW:', uiTotals.unblended.toFixed(2));
        console.log('Account Enablement Fee(UI):', formatCompactUSD(uiTotals.annual), '| RAW:', uiTotals.annual.toFixed(2));
        console.log('Baseline Q Consumption(UI):', formatCompactUSD(uiTotals.baseline), '| RAW:', uiTotals.baseline.toFixed(2));

        console.log(`\n============ ${period} BIGQUERY vs UI VALIDATION ============`);
        const validations = [
            {
                period,
                name: 'PCS Enabler Cost',
                ui: uiTotals.pcs,
                bigquery: bq.pcs
            },
            {
                period,
                name: 'Operations & Security',
                ui: uiTotals.mgmt,
                bigquery: bq.mgmt
            },
            {
                period,
                name: 'Actual Cost',
                ui: uiTotals.unblended,
                bigquery: bq.unblended
            },
            {
                period,
                name: 'Account Enablement Fee',
                ui: uiTotals.annual,
                bigquery: bq.annual
            },
            {
                period,
                name: 'Baseline Q Consumption',
                ui: uiTotals.baseline,
                bigquery: bq.baseline
            }
        ];
        for (const item of validations) {
            const uiFormatted = formatCompactUSD(item.ui);
            const bqFormatted = formatCompactUSD(item.bigquery);
            const difference = Math.abs(item.ui - item.bigquery);
            let diffFormatted = '$0.00';
            if (uiFormatted.includes('M')) {
                diffFormatted = `$${(difference / 1_000_000).toFixed(2)}M`;
            } else if (uiFormatted.includes('K')) {
                diffFormatted = `$${(difference / 1_000).toFixed(2)}K`;
            } else {
                diffFormatted = `$${difference.toFixed(2)}`;
            }
            let isMatch = uiFormatted === bqFormatted;
            if (!isMatch) {
                if (diffFormatted.includes('M') &&
                    parseFloat(diffFormatted.replace('$', '').replace('M', '')) <= 0.01
                ) {
                    isMatch = true;
                }

                else if (
                    diffFormatted.includes('K') && parseFloat(diffFormatted.replace('$', '').replace('K', '')) <= 0.01
                ) {
                    isMatch = true;
                }
                else if (
                    !diffFormatted.includes('M') && !diffFormatted.includes('K') && difference <= 0.01
                ) {
                    isMatch = true;
                }
            }
            reportRows.push({
                period: item.period,
                column: item.name,
                ui: item.ui,
                bigquery: item.bigquery,
                uiValue: uiFormatted,
                bigqueryValue: bqFormatted,
                difference: diffFormatted,
                status: isMatch ? 'PASS' : 'FAIL'
            });

            if (isMatch) {
                console.log(`SUCCESSFULLY MATCHED BIGQUERY vs UI: ${item.period} - ${item.name}`);
                console.log(`BQ VALUE  : ${bqFormatted}`);
                console.log(`UI VALUE : ${uiFormatted}`);
                if (uiFormatted === bqFormatted) {
                    console.log(`DIFF: $0.00\n`);
                } else {
                    console.log(`DIFF : ${diffFormatted}\n`);
                }
            } else {
                console.log(`MISMATCH BIGQUERY vs UI: ${item.period} - ${item.name}`);
                console.log(`BQ VALUE : ${bqFormatted}`);
                console.log(`UI VALUE : ${uiFormatted}`);
                console.log(`DIFF: ${diffFormatted}\n`);
                failedColumns.push(`${item.period} - ${item.name}`);
            }
        }
    }
    if (failedColumns.length > 0) {

        console.log(`============= FAILED VALIDATIONS =============
            ${failedColumns.join('\n')}
            ==============================================`);
    } else {
        console.log('\nBigQuery vs UI Validated Successfully');
    }
    const htmlReport = buildHtmlReport(reportRows);
    await testInfo.attach('BigQuery vs UI Report',
        {
            body: htmlReport,
            contentType: 'text/html'
        }
    );

    fs.writeFileSync(
        'bigquery-report.html',
        htmlReport
    );
});