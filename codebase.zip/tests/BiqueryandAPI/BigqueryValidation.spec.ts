import { test, expect } from '@playwright/test';
import { Pagination } from '../../pages/DashboardPage';
import { bigqueryTableValidation } from '../../utils/bigquery';
import { testDataParams } from '../../locators/dashboardLocators';
import { ENV } from '../../utils/env';


let bigqueryTotals: any;

test.beforeAll(async () => {
    console.log('Running BigQuery Data ');
    bigqueryTotals = await bigqueryTableValidation();
});

function parseCurrency(value: string | null): number {
    if (!value) return 0;
    value = value.replace(/[$,]/g, '').trim();
    if (value.includes('K')) return parseFloat(value) * 1000;
    if (value.includes('M')) return parseFloat(value) * 1000000;
    return parseFloat(value);
}

const tableData = (columnName: string) =>
    `xpath=//th[descendant::p[contains(., '${columnName}')]]/ancestor::table//tr[last()]/td[count(//th[descendant::p[contains(., '${columnName}')]]/preceding-sibling::th) + 1]`;

test('Validate BigQuery vs UI', async ({ page }) => {

    const dashboardPage = new Pagination(page);
    const parameter = testDataParams.currencyFlow;

    //Navigate to website

    await page.goto(ENV.DASHBOARD_URL);
    await expect(page).toHaveURL(/dashboard/);

    await test.step('WHEN user navigates to Charge Analysis Page', async () => {
        await dashboardPage.navigateToAWS();
        await dashboardPage.clickDropdown(parameter.dropdownCost);
        await dashboardPage.clickViewButton(parameter.viewButton);

        await dashboardPage.waitForPageReady();

        await dashboardPage.clickDropdown(parameter.dropdownTable);
        await dashboardPage.waitForPageReady();
    });

    await test.step('THEN verify table loaded with default Pagination', async () => {
        await dashboardPage.verifyTableLoadedValidation();
    });

    await test.step('Apply This Month filter and load table', async () => {
        await dashboardPage.openFilter();
        await page.click('text=This Month');
        await dashboardPage.applyFilter();
        await dashboardPage.verifyTableLoaded();
    });

    function formatCompactUSD(value: number): string {
        if (value >= 1_000_000) {
            return `$${(value / 1_000_000).toFixed(2)}M`;
        } else if (value >= 1_000) {
            return `$${(value / 1_000).toFixed(2)}K`;
        } else {
            return `$${value.toFixed(2)}`;
        }
    }

    const uiTotals = {
        pcs: parseCurrency(await page.locator(tableData('PCS Enabler Cost')).textContent()),
        mgmt: parseCurrency(await page.locator(tableData('Operations & Security')).textContent()),
        unblended: parseCurrency(await page.locator(tableData('Actual Cost')).textContent()),
        annual: parseCurrency(await page.locator(tableData('Account Enablement Fee')).textContent())
    };


    console.log('============ UI TOTAL VALIDATION ============');

    console.log('PCS Enabler Cost(UI):', formatCompactUSD(uiTotals.pcs), '| RAW:', uiTotals.pcs.toFixed(2));
    console.log('Operations & Security(UI):', formatCompactUSD(uiTotals.mgmt), '| RAW:', uiTotals.mgmt.toFixed(2));
    console.log('Actual Cost(UI):', formatCompactUSD(uiTotals.unblended), '| RAW:', uiTotals.unblended.toFixed(2));
    console.log('Account Enablement Fee(UI):', formatCompactUSD(uiTotals.annual), '| RAW:', uiTotals.annual.toFixed(2));

    console.log('============ BIGQUERY TOTAL VALIDATION ============');

    console.log('PCS Enabler Cost(BIGQUERY):', formatCompactUSD(bigqueryTotals.pcs), '| RAW:', bigqueryTotals.pcs);
    console.log('Operations & Security(BIGQUERY):', formatCompactUSD(bigqueryTotals.mgmt), '| RAW:', bigqueryTotals.mgmt);
    console.log('Actual Cost(BIGQUERY):', formatCompactUSD(bigqueryTotals.unblended), '| RAW:', bigqueryTotals.unblended);
    console.log('Account Enablement Fee(BIGQUERY):', formatCompactUSD(bigqueryTotals.annual), '| RAW:', bigqueryTotals.annual);

    const tolerance = 0.01;

    const validations = [
        { name: 'PCS Enabler Cost', ui: uiTotals.pcs, bigquery: bigqueryTotals.pcs },
        { name: 'Operations & Security', ui: uiTotals.mgmt, bigquery: bigqueryTotals.mgmt },
        { name: 'Actual Cost', ui: uiTotals.unblended, bigquery: bigqueryTotals.unblended },
        { name: 'Account Enablement Fee', ui: uiTotals.annual, bigquery: bigqueryTotals.annual }
    ];

    const failedColumns: string[] = [];
    console.log('============ BIGQUERY vs UI VALIDATION ============');
    for (const item of validations) {
        const difference = Math.abs(item.ui - item.bigquery);
        if (difference <= tolerance) {
            console.log(`UI vs BIGQUERY DATA Matched successfully: ${item.name}`);
            console.log(`UI  : ${formatCompactUSD(item.ui)} | RAW: ${item.ui}`);
            console.log(`BIGQUERY : ${formatCompactUSD(item.bigquery)} | RAW: ${item.bigquery}`);
            console.log(`DIFF: ${difference.toFixed(4)}\n`);

        } else {
            console.log(`UI VS BIGQUERY DATA Mismatched: ${item.name}`);
            console.log(`UI  : ${formatCompactUSD(item.ui)} | RAW: ${item.ui}`);
            console.log(`BIGQUERY : ${formatCompactUSD(item.bigquery)} | RAW: ${item.bigquery}`);
            console.log(`DIFF: ${difference.toFixed(4)}\n`);
            failedColumns.push(item.name);
        }
    }
    if (failedColumns.length > 0) {
        console.log(` Validation FAILED for: ${failedColumns.join(', ')}`);
    } else {
        console.log('BigQuery vs UI Validated Successfully');
    }

    console.log('BigQuery vs UI Data Validated Successfully');
});