import { test, expect } from '@playwright/test';
import { Pagination } from '../../pages/DashboardPage';
import { ENV } from '../../utils/env';
import { testDataParams } from '../../locators/dashboardLocators';
import { TableInteractionPage } from '../../pages/Sorting';

test.describe('Sorting Validation - Cost by On Demand Table', () => {
    let dashboardPage: Pagination;
    let tableInteractionPage: TableInteractionPage;

    test.beforeEach(async ({ page }) => {
        dashboardPage = new Pagination(page);
        tableInteractionPage = new TableInteractionPage(page);

        await test.step('Launch Application', async () => {
            await page.goto(ENV.DASHBOARD_URL);
            await expect(page).toHaveURL(/dashboard/);
        });

        await test.step('Navigate to Cost by On Demand Table', async () => {
            const parameter = testDataParams.costFlow;

            await dashboardPage.navigateToAWS();
            await dashboardPage.clickDropdown(parameter.dropdownCloud);
            await dashboardPage.clickViewButton(parameter.viewButton);
            await dashboardPage.waitForPageReady();
            await dashboardPage.clickDropdown(parameter.dropdownTable);
        });
    });

    test('Sorting Validation', async () => {
        const parameter = testDataParams.costFlow;

        await test.step('Verify table loaded', async () => {
            await dashboardPage.verifyTableLoadedValidation();
        });

        await test.step('Verify pagination', async () => {
            await dashboardPage.verifyPaginationControlValidation();
            await dashboardPage.verifyNavigationControlValidation();
        });


        await test.step('TC_SORT_001 - Ascending Sorting', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifyAscendingSort(column);
            }
        });


        await test.step('TC_SORT_002 - Descending Sorting', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifyDescendingSort(column);
            }
        });


        await test.step('TC_SORT_003 - Toggle Sorting', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifyToggleSortingCycle(column);
            }
        });


        await test.step('TC_SORT_004 - Numeric Sorting', async () => {
            await tableInteractionPage.verifyNumericSorting(parameter.numericColumn);
        });


        await test.step('TC_SORT_005 - Currency Sorting', async () => {
            await tableInteractionPage.verifyCurrencySorting(parameter.currencyColumn);
        });


        await test.step('TC_SORT_006 - Pagination Sorting', async () => {
            await tableInteractionPage.verifyPaginationSorting(
                parameter.columnsToSorting[0],
                'asc'
            );
        });

        await test.step('TC_SORT_007 - Sorting with Filters', async () => {
            for (const column of parameter.columnsToSort) {
                await tableInteractionPage.verifySortingWithFilterRetention(
                    column,
                    'Account ID',
                    '003098199196'
                );
            }
        });


        await test.step('TC_SORT_008 - Empty Dataset Sorting', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifyEmptySorting(column);
            }
        });


        await test.step('TC_SORT_009 - Sorting Icon', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifySortingIconUpdatesCorrectly(column);
            }
        });


        await test.step('TC_SORT_010 - Active Column Highlight', async () => {
            await tableInteractionPage.verifyActiveColumnHighlight(
                parameter.columnsToSorting[0],
                parameter.columnsToSorting[1]
            );
        });


        await test.step('TC_SORT_011 - No Flickering', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifyNoFlickeringDuringSorting(column);
            }
        });

        await test.step('TC_SORT_012 - Alignment Validation', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifyColumnAlignmentAfterSorting(column);
            }
        });


        await test.step('TC_SORT_013 - Loader Validation', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifyLoaderVisibleDuringSorting(column);
            }
        });

        await test.step('TC_SORT_014 - Null Values', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifySortingWithNullValues(column);
            }
        });

        await test.step('TC_SORT_015 - Mixed Data Types', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifySortingWithMixedDataTypes(column);
            }
        });

        await test.step('TC_SORT_016 - API Failure', async () => {
            for (const column of parameter.columnsToSorting) {
                await dashboardPage.verifyGracefulApiFailureHandling(column);
            }
        });

        await test.step('TC_SORT_017 - Rapid Click Sorting', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifyRapidSortingClicks(column);
            }
        });

        await test.step('TC_SORT_018 - Sorting After Refresh', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifySortingAfterDataRefresh(column);
            }
        });

        await test.step('TC_SORT_019 - Duplicate Values', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifySortingWithDuplicateValues(column);
            }
        });

        await test.step('TC_SORT_020 - Perfomance Validation', async () => {
            for (const column of parameter.columnsToSorting) {
                await tableInteractionPage.verifyTableLoadPerformance(column);
            }
        });
    });
});
