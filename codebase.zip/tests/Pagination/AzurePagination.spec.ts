/**
* ==============================================================================================
TEST SUITE: Azure Cloud Asset Pagination & Data Grid Validation Matrix
* PURPOSE:    Validates end-to-end table grid integrity, traversal UI/UX mechanics, data density
*             transformations, currency/date localization, sorting correctness, and API fault survival.

* * ==============================================================================================
*/

import { test, expect } from '@playwright/test';
import { Pagination } from '../../pages/DashboardPage';
import { ENV } from '../../utils/env';
import { testDataParams } from '../../locators/dashboardLocators';

test.describe('Pagination Validation for Microsoft Azure', () => {
    let dashboardPage: Pagination;

    test.beforeEach(async ({ page }) => {
        dashboardPage = new Pagination(page);

        await test.step('WHEN user launches Vodafone dashboard', async () => {
            await page.goto(ENV.DASHBOARD_URL);
            await expect(page).toHaveURL(/dashboard/);
        });
    });

    test('Recommendation Table Complete Pagination Validation', async () => {
        const parameter = testDataParams.costFlow;

        await test.step('WHEN user navigates to Recommendation Table Page', async () => {
            await dashboardPage.navigateToAzure();
            await dashboardPage.clickDropdown1(parameter.dropdownCloud);
            await dashboardPage.clickViewButton1(parameter.viewButtonAzure);
            await dashboardPage.waitForPageReady();
            await dashboardPage.clickDropdown(parameter.dropdownTableAzure);
        });

        await test.step('THEN verify table loaded with default Pagination', async () => {
            await dashboardPage.verifyTableLoadedValidation();
            await dashboardPage.verifyTableLoadPerformanceValidation(5000);

        });

        await test.step('AND verify Pagination controls Visibility', async () => {
            await dashboardPage.verifyPaginationControlValidation();
        });

        await test.step('AND verify Navigation controls functionality', async () => {
            await dashboardPage.verifyNavigationControlValidation();
        });

        await test.step('AND verify rows per page sizing and resetting', async () => {
            await dashboardPage.verifyPageSizeScenarioValidation();
            await dashboardPage.verifyPageResetAfterPageSizeChange();
            await dashboardPage.verifyPaginationCountValidation();
        });

        await test.step('AND verify Sorting changes table data content', async () => {
            await dashboardPage.verifySortingWithPaginationValidation(parameter.columnsToSortAzure[0]);
            await dashboardPage.verifySortingWithPaginationValidation(parameter.columnsToSortAzure[1]);
        });

        await test.step('AND apply filter and verify pagination bounds', async () => {
            await dashboardPage.verifyFilterPaginationValidation();
        });

          await test.step('AND verify extreme Edge Cases', async () => {
            await dashboardPage.verifyEdgeCaseValidation(parameter.dropdownTableAzure);
        });

        await test.step('AND verify UI UX compliance', async () => {
            await dashboardPage.verifyUIUXValidation();
        });

        await test.step('AND verify Last page redirect routing', async () => {
            await dashboardPage.verifyLastPageBugValidation(parameter.dropdownTableAzure);
        });

        await test.step('AND verify Graceful API Failure Handling fallbacks', async () => {
            await dashboardPage.verifyGracefulApiFailureHandling(parameter.apiKeywordAzure);
        });
    });


});