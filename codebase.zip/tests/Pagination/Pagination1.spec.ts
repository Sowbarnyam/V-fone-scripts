/**
* ==============================================================================================
TEST SUITE: AWS Cloud Asset Pagination & Data Grid Validation Matrix
* PURPOSE:    Validates end-to-end table grid integrity, traversal UI/UX mechanics, data density
*             transformations, currency/date localization, sorting correctness, and API fault survival.
* TARGETS:    1. EC2 Instance Dashboard Fleet Metrics
*             2. On-Demand Compute Cost Aggregations & Localized Currencies
*             3. Validating Graph vs Table data 
* * ==============================================================================================
*/

import { test, expect } from '@playwright/test';
import { Pagination } from '../../pages/DashboardPage';
import { ENV } from '../../utils/env';
import { testDataParams } from '../../locators/dashboardLocators';

test.describe('Pagination Validation', () => {
    let dashboardPage: Pagination;

    test.beforeEach(async ({ page }) => {
        dashboardPage = new Pagination(page);

        await test.step('WHEN user launches Vodafone dashboard', async () => {
            await page.goto(ENV.DASHBOARD_URL);
            await expect(page).toHaveURL(/dashboard/);
        });
    });

    test('EC2 Instance Complete Pagination and Table Validation', async () => {
        const parameter = testDataParams.ec2Flow;

        await test.step('WHEN user navigates to EC2 Instance Page', async () => {
            await dashboardPage.navigateToAWS();
            await dashboardPage.clickDropdown(parameter.dropdownAsset);
            await dashboardPage.clickViewButton(parameter.viewButton);
            await dashboardPage.waitForPageReady();
            await dashboardPage.clickDropdown(parameter.dropdownTable);
        });



        await test.step('AND verify table loaded with default Pagination', async () => {
            await dashboardPage.verifyTableLoadedValidation();
            await dashboardPage.verifyTableLoadPerformanceValidation(5000);

        });

        await test.step('AND verify Pagination controls Visibility', async () => {
            await dashboardPage.verifyPaginationControlValidation();
        });

        await test.step('AND verify Navigation controls functionality', async () => {
            await dashboardPage.verifyNavigationControlValidation();
        });

        await test.step('AND verify rows per page sizing and resetting', async () => {
            await dashboardPage.verifyPageSizeScenarioValidation();
            await dashboardPage.verifyPageResetAfterPageSizeChange();
            await dashboardPage.verifyPaginationCountValidation();
        });

        await test.step('AND verify Sorting changes table data content', async () => {
            await dashboardPage.verifySortingWithPaginationValidation(parameter.columnsToSort[0]);
            await dashboardPage.verifySortingWithPaginationValidation(parameter.columnsToSort[1]);
        });

        await test.step('AND apply filter and verify pagination bounds', async () => {
            await dashboardPage.verifyFilterPaginationValidation();
            await dashboardPage.verifyTableLoadPerformanceValidation(5000);

        });

        await test.step('AND verify extreme Edge Cases', async () => {
            await dashboardPage.verifyEdgeCaseValidation(parameter.dropdownTable);
        });

        await test.step('AND verify UI UX compliance', async () => {
            await dashboardPage.verifyUIUXValidation();
        });

        await test.step('AND verify Last page redirect routing', async () => {
            await dashboardPage.verifyLastPageBugValidation(parameter.dropdownTable);
        });

        await test.step('AND verify system performance with Large Dataset', async () => {
            await dashboardPage.verifyLargeDatasetValidation();
        });

        await test.step('AND verify Launch Time Date format match', async () => {
            await dashboardPage.verifyDateFormat(parameter.dateColumn);
        });

        await test.step('AND verify Graceful API Failure Handling fallbacks', async () => {
            await dashboardPage.verifyGracefulApiFailureHandling(parameter.apiKeyWord);
        });
    });

    test('Verify On-Demand Compute Cost and Currency Validation', async () => {
        const parameter = testDataParams.costFlow;

        await test.step('WHEN user navigates to Cost By On-Demand Compute', async () => {
            await dashboardPage.navigateToAWS();
            await dashboardPage.clickDropdown(parameter.dropdownCloud);
            await dashboardPage.clickViewButton(parameter.viewButton);
            await dashboardPage.waitForPageReady();
            await dashboardPage.clickDropdown(parameter.dropdownTable);
        });

        await test.step('THEN verify table loaded with default Pagination', async () => {
            await dashboardPage.verifyTableLoadedValidation();
            await dashboardPage.verifyTableLoadPerformanceValidation(5000);

        });

        await test.step('AND verify Pagination controls Visibility', async () => {
            await dashboardPage.verifyPaginationControlValidation();
        });

        await test.step('AND verify Navigation controls functionality', async () => {
            await dashboardPage.verifyNavigationControlValidation();
        });

        await test.step('AND verify rows per page sizing and resetting', async () => {
            await dashboardPage.verifyPageSizeScenarioValidation();
            await dashboardPage.verifyPageResetAfterPageSizeChange();
            await dashboardPage.verifyPaginationCountValidation();
        });

        await test.step('AND verify Sorting changes table data content', async () => {
            await dashboardPage.verifySortingWithPaginationValidation(parameter.columnsToSort[0]);
            await dashboardPage.verifySortingWithPaginationValidation(parameter.columnsToSort[1]);
        });

        await test.step('AND apply filter and verify pagination bounds', async () => {
            await dashboardPage.verifyFilterPaginationValidation();
            await dashboardPage.verifyTableLoadPerformanceValidation(5000);

        });

        await test.step('AND verify extreme Edge Cases', async () => {
            await dashboardPage.verifyEdgeCaseValidation(parameter.dropdownTable);
        });

        await test.step('AND verify UI UX compliance', async () => {
            await dashboardPage.verifyUIUXValidation();
        });

        await test.step('AND verify Last page redirect routing', async () => {
            await dashboardPage.verifyLastPageBugValidation(parameter.dropdownTable);
        });

        await test.step('AND verify system performance with Large Dataset', async () => {
            await dashboardPage.verifyLargeDatasetValidation();
        });

        await test.step('AND verify Currency formatting', async () => {
            await dashboardPage.verifyCurrencyFormat(parameter.currencyColumn, parameter.currencySymbol);
        });

        await test.step('AND verify Graceful API Failure Handling fallbacks', async () => {
            await dashboardPage.verifyGracefulApiFailureHandling(parameter.apiKeyWord);
        });
    });

    test('Table Data and Graph Data Validation', async () => {
        const parameter = testDataParams.currencyFlow;

        await test.step('WHEN user navigates to Charge Analysis Page', async () => {
            await dashboardPage.navigateToAWS();
            await dashboardPage.clickDropdown(parameter.dropdownCost);
            await dashboardPage.clickViewButton(parameter.viewButton);
            await dashboardPage.waitForPageReady();
            await dashboardPage.clickDropdown(parameter.dropdownTable);
        });

        await test.step('THEN verify table loaded with default Pagination', async () => {
            await dashboardPage.verifyTableLoadedValidation();
            await dashboardPage.verifyTableLoadPerformanceValidation(5000);
        });

        await test.step('AND verify Table data and graph validation', async () => {
            await dashboardPage.verifyGraphAndTableData(['Total Cost', 'Actual Cost', 'Operations & Security', 'PCS Enabler Cost', 'Account Enablement Fee ']);
        });

        await test.step('AND verify Table data and graph validation after filtering', async () => {
            await dashboardPage.verifyGraphAndTableDataAfterFiltering(['Total Cost', 'Actual Cost', 'Operations & Security', 'PCS Enabler Cost', 'Account Enablement Fee ']);

        });

    });
});