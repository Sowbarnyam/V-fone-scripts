import { test, expect } from '@playwright/test';
import { Pagination } from '../../pages/DashboardPage';
import { ENV } from '../../utils/env';
import { testDataParams } from '../../locators/dashboardLocators';
import { CurrencyPage } from '../../pages/Currency';
import { CurrencyValidationPage as CurrencyValidationPage } from '../../pages/CurrencyValidation';
import { currencyLocators } from '../../locators/CurrencyLocators';

test.describe('Currency Validation for Gcp', () => {
    let dashboardPage: Pagination;
    let currencyPage: CurrencyPage;
    let validationPage: CurrencyValidationPage;

    test.beforeEach(async ({ page }) => {
        dashboardPage = new Pagination(page);
        currencyPage = new CurrencyPage(page);
        validationPage = new CurrencyValidationPage(page);

        await test.step('WHEN user launches Vodafone dashboard', async () => {
            await page.goto(ENV.DASHBOARD_URL);
            await expect(page).toHaveURL(/dashboard/);
        });
    });

    
    test('Verify Extended Support Charge Recommendations table for Currency Validation In Gcp Page', async () => {
        const parameter = testDataParams.costFlow;
        const parameter1 = testDataParams.currency;

        await test.step('WHEN user navigates to Extended Support Charge Recommendations table', async () => {
            await dashboardPage.navigateToGCP();
            await dashboardPage.clickDropdown1(parameter.dropdownCloud);
            await dashboardPage.clickViewButton1(parameter.dropdownView1);
            await dashboardPage.waitForPageReady();
            await dashboardPage.clickDropdown(parameter.dropdown);
        });

        await test.step('THEN verify table loaded with default Pagination', async () => {
            await dashboardPage.verifyTableLoadedValidation();
        });

        await test.step('AND verify Pagination controls Visibility', async () => {
            await dashboardPage.verifyPaginationControlValidation();
        });

        await test.step('AND verify Currency formatting', async () => {
            const columns = [
                parameter1.currencyColumn1,
            ];
            await validationPage.verifySymbolValidation(columns, parameter1.currencySymbol);
        });

        await test.step('AND validate currency values', async () => {
            await validationPage.verifyCurrencyThousandFormatting();
        });

        await test.step('AND verify Currency column has consistent decimal precision', async () => {
            await currencyPage.validateCurrencyDecimalData();
        });

        await test.step('AND verify large value validation', async () => {
            const columns = [
                parameter1.currencyColumn1,
            ];
            await validationPage.verifyLargeValueReadabilityWorkflow(columns);
        });

        await test.step('AND verify symbol UI validation alignment across pages', async () => {
            const columns = [
                parameter1.currencyColumn1,
            ];
            await validationPage.verifySymbolAlignmentWorkflow(columns);
        });

        await test.step('AND verify No UI Breaking validation', async () => {
            await currencyPage.verifyNoUIBreakingForLargeNumbers(parameter1.currencyColumn1);
        });

        await test.step('AND verify Responsiveness validation', async () => {
            await currencyPage.verifyResponsiveValidation(parameter1.currencyColumn1);
        });

        await test.step('AND verify Alignment validation', async () => {
            await currencyPage.verifyConsistentAlignmentAcrossRows(parameter1.currencyColumn1);
        });

        await test.step('AND verify Non-Zero and Positive Value validation', async () => {
            await currencyPage.verifyNoNegativeOrZeroValues(parameter1.currencyColumn1);
        });

        await test.step('AND verify Single Currency Dataset validation', async () => {
            await currencyPage.verifyMixedCurrencyDataset(parameter1.currencyColumn1);
        });

        await test.step('AND verify Small Decimal Allowances validation', async () => {
            await currencyPage.verifySmallDecimalAllowances(parameter1.currencyColumn1, 0.0001);
        });

        await test.step('AND verify Tooltip Full Value Display validation', async () => {
            await currencyPage.verifyTooltipShowsFullValues(parameter1.currencyColumn1, currencyLocators.tooltip);
        });
    });
});


