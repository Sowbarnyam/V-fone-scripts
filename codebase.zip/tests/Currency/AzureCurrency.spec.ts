import { test, expect } from '@playwright/test';
import { Pagination } from '../../pages/DashboardPage';
import { ENV } from '../../utils/env';
import { testDataParams } from '../../locators/dashboardLocators';
import { CurrencyPage } from '../../pages/Currency';
import { CurrencyValidationPage as CurrencyValidationPage } from '../../pages/CurrencyValidation';
import { currencyLocators } from '../../locators/CurrencyLocators';

test.describe('Currency Validation for Microsoft Azure', () => {
    let dashboardPage: Pagination;
    let currencyPage: CurrencyPage;
    let validationPage: CurrencyValidationPage;

    test.beforeEach(async ({ page }) => {
        dashboardPage = new Pagination(page);
        currencyPage = new CurrencyPage(page);
        validationPage = new CurrencyValidationPage(page);

        await test.step('WHEN user launches Vodafone dashboard', async () => {
            await page.goto(ENV.DASHBOARD_URL);
            await expect(page).toHaveURL(/dashboard/);
        });
    });

    test('Currency Symbol, Pagination and Table Validation', async () => {
        const parameter = testDataParams.currencyFlow;

        await test.step('WHEN user navigates to Charge Analysis Page', async () => {
            await dashboardPage.navigateToAzure();
            await dashboardPage.clickViewButton1(parameter.viewButtonAzure);
            await dashboardPage.waitForPageReady();
            await dashboardPage.clickDropdown(parameter.dropdownTable);
        });

        await test.step('THEN verify table loaded with default Pagination', async () => {
            await dashboardPage.verifyTableLoadedValidation();
        });

        await test.step('AND verify Pagination controls Visibility', async () => {
            await dashboardPage.verifyPaginationControlValidation();
        });

        await test.step('AND verify Currency formatting', async () => {
            const columns = [
                parameter.currencyColumn,
                parameter.currencyColumn1,
                parameter.currencyColumn2,
                parameter.currencyColumn3,
                parameter.currencyColumn4
            ];
            await validationPage.verifySymbolValidation(columns, parameter.currencySymbol1);
        });


        await test.step('AND validate currency values', async () => {
            await validationPage.verifyCurrencyThousandFormatting();
        });

        await test.step('AND verify Currency column has consistent decimal precision', async () => {
            await currencyPage.validateCurrencyDecimalData();
        });

        await test.step('AND verify large value validation', async () => {
            const columns = [
                parameter.currencyColumn,
                parameter.currencyColumn1,
                parameter.currencyColumn2,
                parameter.currencyColumn3,
                parameter.currencyColumn4
            ];
            await validationPage.verifyLargeValueReadabilityWorkflow(columns);
        });

        await test.step('AND verify symbol UI validation alignment across pages', async () => {
            const columns = [
                parameter.currencyColumn,
                parameter.currencyColumn1,
                parameter.currencyColumn2,
                parameter.currencyColumn3,
                parameter.currencyColumn4
            ];
            await validationPage.verifySymbolAlignmentWorkflow(columns);
        });

        await test.step('AND verify No UI Breaking validation', async () => {
            await currencyPage.verifyNoUIBreakingForLargeNumbers(parameter.currencyColumn3);
        });

        await test.step('AND verify Responsiveness validation', async () => {
            await currencyPage.verifyResponsiveValidation(parameter.currencyColumn1);
        });

        await test.step('AND verify Alignment validation', async () => {
            await currencyPage.verifyConsistentAlignmentAcrossRows(parameter.currencyColumn);
        });

        await test.step('AND verify Non-Zero and Positive Value validation', async () => {
            await currencyPage.verifyNoNegativeOrZeroValues(parameter.currencyColumn2);
        });

        await test.step('AND verify Single Currency Dataset validation', async () => {
            await currencyPage.verifyMixedCurrencyDataset(parameter.currencyColumn4);
        });

        await test.step('AND verify Small Decimal Allowances validation', async () => {
            await currencyPage.verifySmallDecimalAllowances(parameter.currencyColumn, 0.0001);
        });

        await test.step('AND verify Tooltip Full Value Display validation', async () => {
            await currencyPage.verifyTooltipShowsFullValues(parameter.currencyColumn, currencyLocators.tooltip);
        });
    });
});


