import { test } from '@playwright/test';
import { LoginPage } from '../../pages/LoginPage';
import { ENV } from '../../utils/env';
import { logger } from '../../utils/logger';
import { loginLocators } from '../../locators/loginLocators';

test('Authenticate User Session state', async ({ page }) => {
    logger.info('Executing authorization seed setup step...');
    const loginPage = new LoginPage(page);
    await page.context().clearCookies();
    await loginPage.navigateToLoginPage();
    await page.waitForLoadState('networkidle');
    const isEmailPresent = await page.locator(loginLocators.authEmailInput).isVisible({ timeout: 10000 }).catch(() => false);
    const isPasswordPresent = await page.locator(loginLocators.authPassword).isVisible({ timeout: 10000 }).catch(() => false);
    if (isEmailPresent || isPasswordPresent) {
        logger.info('Login elements detected. Executing full authentication flow...');
        if (isEmailPresent) {
            await loginPage.login(ENV.EMAIL);
            await page.waitForLoadState('networkidle');
        }
        await loginPage.authenticationLogin();
    } else {
        logger.info('Direct landing achieved. No credentials needed, session already active.');
        await page.waitForURL(loginLocators.dashboardUrl, { timeout: 20000 });
    }
    const authStatePath = 'playwright/.auth/user.json';
    await page.context().storageState({ path: authStatePath });
    logger.info(`Saved authenticated storage state token context to path: ${authStatePath}`);
});
